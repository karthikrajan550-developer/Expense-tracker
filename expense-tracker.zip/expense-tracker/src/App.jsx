// =====================================================================
// App.jsx — the "brain" of the app.
// It owns all the important state and every CRUD function, decides
// which PAGE to show (Dashboard / Transactions / Add expense), and passes
// data DOWN to pages and functions DOWN as props.
// =====================================================================
import { useState, useEffect, useCallback, useRef } from "react";
import LoadingScreen from "./components/loading/LoadingScreen";
import Header from "./components/Header";
import TabBar from "./components/TabBar";
import Footer from "./components/Footer";
import Toast from "./components/Toast";
import DashboardPage from "./pages/DashboardPage";
import TransactionsPage from "./pages/TransactionsPage";
import AddPage from "./pages/AddPage";
import useLoadingScreen from "./hooks/useLoadingScreen";
import useInteractiveEffects from "./hooks/useInteractiveEffects";
import useHashRoute from "./hooks/useHashRoute";
import { loadTransactions, saveTransactions } from "./utils/storage";
import { filterByDate, filterTransactions } from "./utils/calculations";
import { formatCurrency } from "./utils/format";
import { TYPE_LABELS, PAGES, PAGE_IDS, DEFAULT_PAGE } from "./data/constants";

const DEFAULT_FILTERS = { type: "all", category: "all", search: "", sortOrder: "newest" };

export default function App() {
  // ---------- STATE ----------
  // Lazy initial state: loadTransactions runs only once, on the first render
  const [transactions, setTransactions] = useState(loadTransactions);
  const [editingTransaction, setEditingTransaction] = useState(null); // null = "add" mode
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [selectedDate, setSelectedDate] = useState(null); // null = all dates
  const [toast, setToast] = useState(null); // null = no pop-up showing
  const [highlightId, setHighlightId] = useState(null); // row that just changed (flashes)

  // Which page is showing: "dashboard" | "transactions" | "add" (mirrored in the URL hash)
  const [route, navigate] = useHashRoute(PAGE_IDS, DEFAULT_PAGE);

  // Loading screen stage: "loading" -> "leaving" -> "done" (see the hook)
  const loadingStage = useLoadingScreen();
  const isReady = loadingStage !== "loading";

  // Ripple, spotlight and card tilt for the whole app (set up once)
  useInteractiveEffects();

  // ---------- SIDE EFFECTS ----------
  // Whenever `transactions` changes, save the new list to localStorage
  useEffect(() => {
    saveTransactions(transactions);
  }, [transactions]);

  // On every page switch: browser-tab title, back to the top, and
  // (after the first page) focus the new page's title for screen readers
  const titleRef = useRef(null);
  const isFirstPageRef = useRef(true);
  useEffect(() => {
    const page = PAGES.find((item) => item.id === route);
    document.title = `${page.title} · Expense Tracker`;
    window.scrollTo({ top: 0, behavior: "instant" });

    if (isFirstPageRef.current) {
      isFirstPageRef.current = false;
    } else {
      titleRef.current?.focus({ preventScroll: true });
    }

    // Leaving the form while editing cancels the edit
    if (route !== "add") setEditingTransaction(null);
  }, [route]);

  // ---------- POP-UP (toast) ----------
  // `id` changes every time, so React treats each toast as new
  // and the animation restarts even if one is already showing
  function showToast(title, message) {
    setToast({ id: Date.now(), title, message });
  }

  // useCallback keeps the same function between renders, so the Toast's
  // timer isn't restarted on every re-render. Hiding the toast also ends
  // the "just changed" row highlight.
  const hideToast = useCallback(() => {
    setToast(null);
    setHighlightId(null);
  }, []);

  // Short summary used in the pop-up, e.g. "Debit of ₹450 · Food"
  function describe(transaction) {
    return `${TYPE_LABELS[transaction.type]} of ${formatCurrency(transaction.amount)} · ${transaction.category}`;
  }

  // ---------- CRUD ----------
  // CREATE: put the new transaction at the top of a NEW array.
  // We stay on the Add page, so several entries can be added in a row.
  function addTransaction(transaction) {
    const newTransaction = { ...transaction, id: Date.now().toString() };
    setTransactions((prev) => [newTransaction, ...prev]);
    setHighlightId(newTransaction.id);
    showToast("Successfully added", describe(newTransaction));
  }

  // UPDATE: replace the transaction that has the same id, then go back
  // to the list, where the changed row flashes
  function updateTransaction(updated) {
    setTransactions((prev) => prev.map((item) => (item.id === updated.id ? updated : item)));
    setEditingTransaction(null);
    setHighlightId(updated.id);
    showToast("Successfully updated", describe(updated));
    navigate("transactions");
  }

  // DELETE: keep every transaction except the one with this id
  // (useCallback: TransactionItem uses it in an effect's dependency list)
  const deleteTransaction = useCallback((id) => {
    setTransactions((prev) => prev.filter((item) => item.id !== id));
  }, []);

  // Edit opens the form page with the row's values filled in
  function startEditing(transaction) {
    setEditingTransaction(transaction);
    navigate("add");
  }

  function cancelEditing() {
    setEditingTransaction(null);
    navigate("transactions");
  }

  // Pick one date (or null for all dates) and scroll up to see the result
  function selectDate(date) {
    setSelectedDate(date);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // ---------- READ (derived data) ----------
  // Calculated on every render, never stored in state.
  // Step 1: the date filter applies to the dashboard, charts and list
  const transactionsOnDate = filterByDate(transactions, selectedDate);
  // Step 2: search / type / category / sort apply to the LIST only
  const visibleTransactions = filterTransactions(transactionsOnDate, filters);

  // ---------- PAGES ----------
  function renderPage() {
    if (route === "transactions") {
      return (
        <TransactionsPage
          allCount={transactions.length}
          dateCount={transactionsOnDate.length}
          visibleTransactions={visibleTransactions}
          filters={filters}
          onFiltersChange={setFilters}
          selectedDate={selectedDate}
          onDateChange={selectDate}
          highlightId={highlightId}
          onEdit={startEditing}
          onDelete={deleteTransaction}
          onNavigate={navigate}
          titleRef={titleRef}
        />
      );
    }

    if (route === "add") {
      return (
        <AddPage
          editingTransaction={editingTransaction}
          onAdd={addTransaction}
          onUpdate={updateTransaction}
          onCancel={cancelEditing}
          titleRef={titleRef}
        />
      );
    }

    return (
      <DashboardPage
        transactions={transactionsOnDate}
        selectedDate={selectedDate}
        onDateChange={selectDate}
        isReady={isReady}
        onNavigate={navigate}
        titleRef={titleRef}
      />
    );
  }

  return (
    // "is-ready" starts the entrance animations once the loader begins to fade
    <div className={`app ${isReady ? "is-ready" : ""}`}>
      {loadingStage !== "done" && <LoadingScreen isLeaving={loadingStage === "leaving"} />}

      {/* Keyboard users can jump straight past the header */}
      <a className="skip-link" href="#main">
        Skip to content
      </a>

      <Header route={route} onNavigate={navigate} />

      {/* key={route}: a new page is a NEW element, so its entrance animation plays */}
      <main className="container page" id="main">
        <div className="page-view" key={route}>
          {renderPage()}
        </div>
      </main>

      <Footer />
      <TabBar route={route} onNavigate={navigate} />

      {/* Conditional rendering: only shown after a successful add/update */}
      {toast && <Toast key={toast.id} title={toast.title} message={toast.message} onClose={hideToast} />}
    </div>
  );
}

// =====================================================================
// Header.jsx — sticky glass navigation bar.
//   - brand (logo + name) on the left: goes to the Dashboard
//   - page tabs on the right; a pill SLIDES to the active tab
//     (measured from the real tab position, so any label length works)
//   - after scrolling a little, the bar gets stronger glass + a shadow
// On phones the tabs move to the bottom TabBar instead.
// =====================================================================
import { useLayoutEffect, useRef, useState } from "react";
import logo from "../assets/logo.png";
import { PAGES } from "../data/constants";
import useScrolled from "../hooks/useScrolled";

export default function Header({ route, onNavigate }) {
  const isScrolled = useScrolled();

  // Position + width of the sliding pill, measured from the active tab
  const tabRefs = useRef({});
  const [indicator, setIndicator] = useState({ left: 0, width: 0 });

  // useLayoutEffect runs after the DOM updates but before the browser
  // paints, so the pill never shows in the wrong place for a frame
  useLayoutEffect(() => {
    function measure() {
      const tab = tabRefs.current[route];
      if (tab) setIndicator({ left: tab.offsetLeft, width: tab.offsetWidth });
    }
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [route]);

  // Links keep a real href (works without JS, can be opened in a new tab),
  // but a normal click is handled by the app's router
  function handleClick(event, id) {
    event.preventDefault();
    onNavigate(id);
  }

  return (
    <header className={`site-header ${isScrolled ? "site-header--scrolled" : ""}`}>
      <div className="container site-header__inner">
        <a className="brand" href="#/dashboard" onClick={(event) => handleClick(event, "dashboard")}>
          <img className="brand__logo" src={logo} alt="" width="38" height="38" />
          <span className="brand__name">Expense Tracker</span>
        </a>

        <nav className="nav" aria-label="Pages">
          <span
            className="nav__indicator"
            style={{ transform: `translateX(${indicator.left}px)`, width: indicator.width }}
            aria-hidden="true"
          />
          {PAGES.map((page) => (
            <a
              key={page.id}
              ref={(element) => (tabRefs.current[page.id] = element)}
              className={`nav-link ${route === page.id ? "is-active" : ""}`}
              href={`#/${page.id}`}
              onClick={(event) => handleClick(event, page.id)}
              aria-current={route === page.id ? "page" : undefined}
            >
              {page.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}

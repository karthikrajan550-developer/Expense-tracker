// =====================================================================
// TabBar.jsx — bottom tab bar for phones (the header has no room for
// links there). Same pages as the header; a pill slides to the active
// tab using --index, like the Bar/Pie switch.
// =====================================================================
import { PAGES } from "../data/constants";
import { ChartIcon, ReceiptIcon, AddNoteIcon } from "./Icons";

const ICONS = { dashboard: ChartIcon, transactions: ReceiptIcon, add: AddNoteIcon };

export default function TabBar({ route, onNavigate }) {
  const activeIndex = PAGES.findIndex((page) => page.id === route);

  return (
    <nav className="tab-bar" aria-label="Pages" style={{ "--index": activeIndex, "--count": PAGES.length }}>
      <span className="tab-bar__indicator" aria-hidden="true" />
      {PAGES.map((page) => {
        const Icon = ICONS[page.id];
        const isActive = page.id === route;
        return (
          <a
            key={page.id}
            href={`#/${page.id}`}
            className={`tab-bar__item ${isActive ? "is-active" : ""}`}
            aria-current={isActive ? "page" : undefined}
            onClick={(event) => {
              event.preventDefault();
              onNavigate(page.id);
            }}
          >
            <Icon size={24} />
            <span>{page.label}</span>
          </a>
        );
      })}
    </nav>
  );
}

// =====================================================================
// Dashboard.jsx — shows Total Balance, Total credit and Total debit.
// Receives the date-filtered transactions and calculates the totals itself,
// so when a date is selected these numbers are for that date only.
// Amounts count up/down smoothly whenever they change (AnimatedNumber).
// =====================================================================
import { getTotals } from "../utils/calculations";
import { formatCurrency } from "../utils/format";
import walletIcon from "../assets/wallet.png";
import creditIcon from "../assets/receive-amount.png";
import debitIcon from "../assets/spending.png";
import AnimatedNumber from "./AnimatedNumber";

export default function Dashboard({ transactions, isReady }) {
  const { credit, debit, balance } = getTotals(transactions);
  const isNegative = balance < 0;

  return (
    <section className="dashboard" aria-label="Account summary">
      <div className="stat stat--balance">
        <div>
          <p className="stat__label">Total Balance</p>
          <p className={`stat__value ${isNegative ? "stat__value--negative" : ""}`}>
            <AnimatedNumber value={balance} format={formatCurrency} isActive={isReady} />
          </p>
          {/* Show a note only when the balance is negative */}
          {isNegative && <p className="stat__note">You have spent more than you received.</p>}
        </div>
        <img className="stat__icon" src={walletIcon} alt="" width="64" height="64" />
      </div>

      <div className="stat stat--credit">
        <div>
          <p className="stat__label">Total credit</p>
          <p className="stat__value">
            <AnimatedNumber value={credit} format={formatCurrency} isActive={isReady} />
          </p>
          <p className="stat__note">Money in</p>
        </div>
        <img className="stat__icon" src={creditIcon} alt="" width="56" height="56" />
      </div>

      <div className="stat stat--debit">
        <div>
          <p className="stat__label">Total debit</p>
          <p className="stat__value">
            <AnimatedNumber value={debit} format={formatCurrency} isActive={isReady} />
          </p>
          <p className="stat__note">Money out</p>
        </div>
        <img className="stat__icon" src={debitIcon} alt="" width="56" height="56" />
      </div>
    </section>
  );
}

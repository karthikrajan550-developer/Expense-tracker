// =====================================================================
// Footer.jsx — one slim row: copyright on the left, back-to-top on the right.
// Uses the same .container as the header and page, so all edges line up.
// =====================================================================
export default function Footer() {
  const year = new Date().getFullYear();

  function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <footer className="site-footer">
      <div className="container site-footer__inner">
        <div className="site-footer__meta">
          <p>© {year} Expense Tracker</p>
          <p>Built with React, Vite and CSS · Your data stays in this browser</p>
        </div>

        <button type="button" className="btn back-to-top" onClick={scrollToTop}>
          <span aria-hidden="true" className="back-to-top__arrow">↑</span>
          Back to top
        </button>
      </div>
    </footer>
  );
}

// =====================================================================
// Icons.jsx — small illustrated icons drawn with inline SVG.
// Style: bright fills + thick dark outline (matches the app logo).
//
// Every icon is a normal React component, so you use it like:
//   <ChartIcon />           -> 32px
//   <ChartIcon size={48} /> -> 48px
// aria-hidden="true" because the icons are decoration; the text next
// to them already says what they mean.
// =====================================================================

// Colours shared by all icons
const C = {
  outline: "#1f2328",
  blue: "#4f63c2",
  paper: "#e8eef7",
  line: "#a9b8e6",
  yellow: "#fdd02b",
  orange: "#f7931e",
  green: "#22a45d",
  red: "#ef5350",
  white: "#ffffff",
};

// Wraps every icon: sets the size and gives all shapes the dark outline
function IconBase({ size, children }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true" focusable="false">
      <g stroke={C.outline} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        {children}
      </g>
    </svg>
  );
}

// Analytics: board with a bar chart
export function ChartIcon({ size = 32 }) {
  return (
    <IconBase size={size}>
      <rect x="5" y="5" width="38" height="38" rx="6" fill={C.paper} />
      <rect x="12" y="24" width="7" height="12" rx="1.5" fill={C.yellow} />
      <rect x="21" y="14" width="7" height="22" rx="1.5" fill={C.green} />
      <rect x="30" y="28" width="7" height="8" rx="1.5" fill={C.red} />
      <path d="M10 36h28" fill="none" />
    </IconBase>
  );
}

// Transactions: receipt with a coin
export function ReceiptIcon({ size = 32 }) {
  return (
    <IconBase size={size}>
      <path d="M9 5h26v37l-4.3-3-4.4 3-4.3-3-4.3 3-4.4-3L9 42z" fill={C.paper} />
      <path d="M15 13h14M15 20h14M15 27h8" stroke={C.line} strokeWidth="3.5" />
      <circle cx="35" cy="34" r="8" fill={C.orange} />
      <circle cx="35" cy="34" r="4" fill={C.yellow} />
    </IconBase>
  );
}

// Add transaction: clipboard with a plus
export function AddNoteIcon({ size = 32 }) {
  return (
    <IconBase size={size}>
      <rect x="6" y="7" width="28" height="36" rx="4" fill={C.blue} />
      <rect x="10" y="12" width="20" height="27" rx="2" fill={C.paper} />
      <rect x="14" y="4" width="12" height="7" rx="2" fill={C.orange} />
      <path d="M14 20h12M14 27h8" stroke={C.line} strokeWidth="3.5" />
      <circle cx="36" cy="36" r="9" fill={C.green} />
      <path d="M36 31.5v9M31.5 36h9" stroke={C.white} />
    </IconBase>
  );
}

// Date filter: calendar
export function CalendarIcon({ size = 32 }) {
  return (
    <IconBase size={size}>
      <rect x="5" y="9" width="38" height="34" rx="5" fill={C.paper} />
      <path d="M5 14a5 5 0 0 1 5-5h28a5 5 0 0 1 5 5v6H5z" fill={C.red} />
      <rect x="13" y="4" width="5" height="10" rx="2.5" fill={C.orange} />
      <rect x="30" y="4" width="5" height="10" rx="2.5" fill={C.orange} />
      <rect x="11" y="25" width="7" height="6" rx="1.5" fill={C.yellow} />
      <rect x="21" y="25" width="7" height="6" rx="1.5" fill={C.line} />
      <rect x="31" y="25" width="7" height="6" rx="1.5" fill={C.line} />
      <rect x="11" y="34" width="7" height="5" rx="1.5" fill={C.line} />
      <rect x="21" y="34" width="7" height="5" rx="1.5" fill={C.green} />
    </IconBase>
  );
}

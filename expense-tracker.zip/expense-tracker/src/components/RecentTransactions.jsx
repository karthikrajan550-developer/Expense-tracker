// =====================================================================
// RecentTransactions.jsx — the 5 newest transactions, for the dashboard.
// Read-only and compact; "View all" switches to the Transactions page.
// =====================================================================
import { ReceiptIcon } from "./Icons";
import { CATEGORY_COLORS } from "../data/constants";
import { sortByDate } from "../utils/calculations";
import { formatCurrency, formatDayHeading } from "../utils/format";

const LIMIT = 5;

export default function RecentTransactions({ transactions, onViewAll }) {
  const recent = sortByDate(transactions, "newest").slice(0, LIMIT);

  return (
    <section className="panel recent" aria-labelledby="recent-heading">
      <div className="panel__header">
        <h2 id="recent-heading" className="heading-with-icon">
          <ReceiptIcon size={28} />
          Recent
        </h2>
        <button type="button" className="btn btn--small" onClick={onViewAll}>
          View all <span aria-hidden="true">→</span>
        </button>
      </div>

      {recent.length === 0 ? (
        <p className="recent__empty">Nothing recorded for this date yet.</p>
      ) : (
        <ul className="recent__list">
          {recent.map((item) => (
            <li key={item.id} className="recent__item" style={{ "--category-color": CATEGORY_COLORS[item.category] }}>
              <span className="recent__dot" aria-hidden="true" />
              <div className="recent__info">
                <p className="recent__title">{item.title}</p>
                <p className="recent__meta">
                  {item.category} · {formatDayHeading(item.date)}
                </p>
              </div>
              <p className={`recent__amount recent__amount--${item.type}`}>
                {item.type === "credit" ? "+" : "−"}
                {formatCurrency(item.amount)}
              </p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

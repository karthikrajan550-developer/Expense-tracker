// =====================================================================
// DateFilter.jsx — choose ONE date, or show all dates.
// The chosen date filters the whole page: dashboard, charts and list.
// It doesn't own the date; it tells App through onDateChange.
//   selectedDate = null          -> all dates
//   selectedDate = "2026-10-27"  -> only that date
// =====================================================================
import { formatDayHeading, getToday, getDateDaysAgo } from "../utils/format";
import { CalendarIcon } from "./Icons";

export default function DateFilter({ selectedDate, onDateChange }) {
  const today = getToday();
  const yesterday = getDateDaysAgo(1);

  return (
    <section
      className={`date-filter ${selectedDate ? "date-filter--active" : ""}`}
      aria-label="Filter by date"
    >
      <div className="date-filter__current">
        <CalendarIcon size={36} />
        <div>
          <p className="date-filter__label">Showing</p>
          <p className="date-filter__value" aria-live="polite">
            {selectedDate ? formatDayHeading(selectedDate) : "All dates"}
          </p>
        </div>
      </div>

      <div className="date-filter__controls">
        <button
          type="button"
          className={`chip ${selectedDate === null ? "is-active" : ""}`}
          aria-pressed={selectedDate === null}
          onClick={() => onDateChange(null)}
        >
          All dates
        </button>
        <button
          type="button"
          className={`chip ${selectedDate === today ? "is-active" : ""}`}
          aria-pressed={selectedDate === today}
          onClick={() => onDateChange(today)}
        >
          Today
        </button>
        <button
          type="button"
          className={`chip ${selectedDate === yesterday ? "is-active" : ""}`}
          aria-pressed={selectedDate === yesterday}
          onClick={() => onDateChange(yesterday)}
        >
          Yesterday
        </button>

        <label className="visually-hidden" htmlFor="date-filter-input">
          Pick a date
        </label>
        <input
          id="date-filter-input"
          type="date"
          max={today}
          value={selectedDate ?? ""}
          // Clearing the picker gives "", which we turn back into null (all dates)
          onChange={(event) => onDateChange(event.target.value || null)}
        />
      </div>
    </section>
  );
}

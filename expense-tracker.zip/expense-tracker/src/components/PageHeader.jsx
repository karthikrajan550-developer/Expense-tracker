// =====================================================================
// PageHeader.jsx — the title block at the top of every page, so all
// pages start the same way: small eyebrow, big title, one line of text,
// and an optional action on the right.
//
// The title gets focus after a page switch (tabIndex -1 makes a heading
// focusable by script), so screen-reader users hear the new page.
// =====================================================================
export default function PageHeader({ eyebrow, title, text, action, titleRef }) {
  return (
    <section className="page-header" aria-labelledby="page-title">
      <div>
        {eyebrow && <p className="page-header__eyebrow">{eyebrow}</p>}
        <h1 id="page-title" ref={titleRef} tabIndex={-1}>
          {title}
        </h1>
        {text && <p className="page-header__text">{text}</p>}
      </div>
      {action && <div className="page-header__action">{action}</div>}
    </section>
  );
}

// =====================================================================
// Toast.jsx — a small pop-up message with an animated tick.
// It appears, stays for TOAST_DURATION, fades out, then calls onClose
// so App can remove it.
//
// The animation itself is pure CSS (see "TOAST" in index.css):
//   1. the box slides + fades in
//   2. the circle pops in
//   3. the tick draws itself (stroke-dashoffset trick)
//   4. near the end, the box fades out
// =====================================================================
import { useEffect } from "react";

export const TOAST_DURATION = 3000; // milliseconds

export default function Toast({ title, message, onClose }) {
  // Start a timer when the toast appears; clear it if the toast is removed early
  useEffect(() => {
    const timer = setTimeout(onClose, TOAST_DURATION);
    return () => clearTimeout(timer); // cleanup function
  }, [onClose]);

  return (
    <div className="toast" role="status" aria-live="polite">
      <svg className="toast__tick" viewBox="0 0 52 52" aria-hidden="true">
        <circle className="toast__tick-circle" cx="26" cy="26" r="23" />
        <path className="toast__tick-check" d="M15.5 27l7 7L37 19.5" />
      </svg>

      <div>
        <p className="toast__title">{title}</p>
        {message && <p className="toast__message">{message}</p>}
      </div>
    </div>
  );
}

// =====================================================================
// AnimatedNumber.jsx — counts smoothly from the old value to the new one.
//   <AnimatedNumber value={balance} format={formatCurrency} isActive={isReady} />
//
// - isActive = false: shows 0 and waits (used while the loader is visible),
//   so the first count-up happens when the user can actually see it.
// - Each change animates from wherever the number currently is, even if
//   a previous animation is still running.
// - Users who prefer reduced motion see the final number straight away.
// =====================================================================
import { useEffect, useRef, useState } from "react";
import { easeOutCubic, prefersReducedMotion } from "../utils/motion";

export default function AnimatedNumber({ value, format, isActive = true, duration = 900 }) {
  const [display, setDisplay] = useState(0);
  const currentRef = useRef(0); // the number on screen right now (no re-render needed)

  useEffect(() => {
    if (!isActive) return undefined;

    const from = currentRef.current;
    if (from === value || prefersReducedMotion()) {
      currentRef.current = value;
      setDisplay(value);
      return undefined;
    }

    let frameId;
    const start = performance.now();

    function tick(now) {
      const t = Math.min((now - start) / duration, 1);
      // Whole rupees while moving, the exact value at the end
      const next = t < 1 ? Math.round(from + (value - from) * easeOutCubic(t)) : value;
      currentRef.current = next;
      setDisplay(next);
      if (t < 1) frameId = requestAnimationFrame(tick);
    }

    frameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameId);
  }, [value, isActive, duration]);

  return <>{format(display)}</>;
}

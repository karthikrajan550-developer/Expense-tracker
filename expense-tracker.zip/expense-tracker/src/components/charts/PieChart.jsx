// =====================================================================
// PieChart.jsx — a reusable pie (donut) chart using CSS conic-gradient.
// Expects the same data shape as BarChart: [{ label, value, color }]
//
// conic-gradient paints colours around a circle, e.g.
//   conic-gradient(red 0% 40%, blue 40% 100%)
// So we just turn each item into "color start% end%".
// =====================================================================
import { formatCurrency, formatCompactCurrency } from "../../utils/format";

export default function PieChart({ data }) {
  const total = data.reduce((sum, item) => sum + item.value, 0);

  // Build the slices one after another, starting at 0%
  let start = 0;
  const slices = data.map((item) => {
    const percent = (item.value / total) * 100;
    const slice = `${item.color} ${start}% ${start + percent}%`;
    start += percent;
    return slice;
  });

  const description = data.map((item) => `${item.label} ${Math.round((item.value / total) * 100)}%`).join(", ");

  return (
    <div className="pie-chart">
      <div
        className="pie-chart__circle"
        style={{ background: `conic-gradient(${slices.join(", ")})` }}
        role="img"
        aria-label={`Pie chart: ${description}`}
      >
        <div className="pie-chart__center">
          <span>Total</span>
          <strong>{formatCompactCurrency(total)}</strong>
        </div>
      </div>

      <ul className="pie-chart__legend">
        {data.map((item) => (
          <li key={item.label}>
            <span className="dot" style={{ backgroundColor: item.color }} />
            <span className="pie-chart__legend-label">{item.label}</span>
            <span className="pie-chart__legend-value">
              {formatCurrency(item.value)} <small>{Math.round((item.value / total) * 100)}%</small>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

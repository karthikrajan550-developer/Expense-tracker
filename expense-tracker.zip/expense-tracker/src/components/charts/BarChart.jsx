// =====================================================================
// BarChart.jsx — a reusable bar chart built with plain divs + CSS.
// Expects data like: [{ label: "Food", value: 3650, color: "#e08e2b" }]
// Each bar's height = its value as a percentage of the biggest value.
// =====================================================================
import { formatCompactCurrency, formatCurrency } from "../../utils/format";

export default function BarChart({ data }) {
  const maxValue = Math.max(...data.map((item) => item.value));
  const description = data.map((item) => `${item.label} ${formatCurrency(item.value)}`).join(", ");

  return (
    <div className="bar-chart" role="img" aria-label={`Bar chart: ${description}`}>
      {data.map((item) => (
        <div className="bar-chart__column" key={item.label}>
          <span className="bar-chart__value">{formatCompactCurrency(item.value)}</span>

          <div className="bar-chart__track">
            <div
              className="bar-chart__bar"
              style={{
                height: `${(item.value / maxValue) * 100}%`,
                backgroundColor: item.color,
              }}
              title={`${item.label}: ${formatCurrency(item.value)}`}
            />
          </div>

          <span className="bar-chart__label">{item.label}</span>
        </div>
      ))}
    </div>
  );
}

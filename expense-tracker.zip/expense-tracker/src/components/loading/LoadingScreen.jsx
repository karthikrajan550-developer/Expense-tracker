// =====================================================================
// LoadingScreen.jsx — full-screen loader shown on open / refresh.
//
// Timeline (all timing is in loading.css, except the two JS constants):
//   0.0s   scene glides in, then title, text and progress bar (stagger)
//   0→2.2s progress counts 0% → 100% (eased), landscape scrolls
//   2.2s   isLeaving = true: rider accelerates off to the right,
//          the whole screen fades, and the app animates in underneath
// =====================================================================
import Scene from "./Scene";
import useProgress from "../../hooks/useProgress";
import { LOADING_TIME } from "../../hooks/useLoadingScreen";
import "./loading.css";

export default function LoadingScreen({ isLeaving }) {
  const progress = useProgress(LOADING_TIME);
  const percent = Math.round(progress * 100);

  return (
    <div className={`loading-screen ${isLeaving ? "loading-screen--leaving" : ""}`} aria-busy={!isLeaving}>
      <div className="loading-screen__stage">
        <Scene />
      </div>

      <p className="loading-screen__title">Expense Tracker</p>
      <p className="loading-screen__text">Loading your expenses…</p>

      <div className="loading-screen__progress">
        <div
          className="loading-screen__bar"
          role="progressbar"
          aria-label="Loading"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={percent}
        >
          {/* scaleX instead of width: transform runs on the GPU, no layout work */}
          <span className="loading-screen__fill" style={{ transform: `scaleX(${progress})` }} />
        </div>
        <span className="loading-screen__percent">{percent}%</span>
      </div>
    </div>
  );
}

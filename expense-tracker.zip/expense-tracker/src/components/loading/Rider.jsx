// =====================================================================
// Rider.jsx — the rider on a scooter, drawn with SVG.
// Coordinates are relative to the REAR WHEEL CENTRE (0, 0).
//
// It is split into parts that move differently, which is what makes
// the motion feel real:
//   wheels  -> spin, but stay on the road (no bobbing)
//   body    -> the scooter bobs on its suspension
//   person  -> bobs too, slightly later (secondary motion)
//   scarf   -> flutters in the wind
//   puffs   -> exhaust smoke drifting back
//   shadow  -> squashes a little as the body bobs
// Each moving group has a CSS class; the timing lives in loading.css.
// =====================================================================

const C = {
  body: "#2f6db3",
  bodyDark: "#24578f",
  gloss: "rgba(255, 255, 255, 0.55)",
  tyre: "#1d2733",
  rim: "#cfd8e2",
  seat: "#1d2733",
  jacket: "#2ecac4",
  jacketShade: "#22aaa5",
  pants: "#2a3a55",
  skin: "#f2c6a0",
  helmet: "#24578f",
  visor: "#16202b",
  scarf: "#ff7a59",
  box: "#fdd02b",
  boxShade: "#e9b90f",
  light: "#fff4b8",
  tailLight: "#ff5a4f",
};

const SPOKE_ANGLES = [0, 72, 144, 216, 288];

function Wheel({ x }) {
  return (
    <g className="rider__wheel" transform={`translate(${x} 0)`}>
      {/* inner group spins; the outer one only positions it */}
      <g className="rider__wheel-spin">
        <circle r="16" fill={C.tyre} />
        <circle r="10" fill={C.rim} />
        {SPOKE_ANGLES.map((angle) => (
          <line
            key={angle}
            x1="0"
            y1="0"
            x2="0"
            y2="-9"
            stroke={C.tyre}
            strokeWidth="1.6"
            transform={`rotate(${angle})`}
          />
        ))}
        <circle r="3" fill={C.tyre} />
      </g>
    </g>
  );
}

export default function Rider() {
  return (
    <g className="rider__art">
      {/* Speed lines streak backwards behind the rider */}
      <g className="rider__speed-lines" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round">
        <line className="speed-line speed-line--1" x1="-70" y1="-96" x2="-40" y2="-96" />
        <line className="speed-line speed-line--2" x1="-90" y1="-62" x2="-54" y2="-62" />
        <line className="speed-line speed-line--3" x1="-78" y1="-30" x2="-50" y2="-30" />
      </g>

      {/* Ground shadow */}
      <ellipse className="rider__shadow" cx="44" cy="17" rx="64" ry="5" fill="rgba(10, 20, 30, 0.28)" />

      {/* Exhaust puffs, each starting a little later */}
      <g className="rider__puffs" fill="#ffffff">
        <circle className="puff puff--1" cx="-32" cy="-4" r="4" />
        <circle className="puff puff--2" cx="-32" cy="-4" r="4" />
        <circle className="puff puff--3" cx="-32" cy="-4" r="4" />
      </g>

      {/* ---------- Scooter body (bobs) ---------- */}
      <g className="rider__body">
        {/* exhaust pipe */}
        <rect x="-28" y="-7" width="20" height="5" rx="2.5" fill="#8a96a3" />

        {/* delivery box on the rear rack */}
        <rect x="-32" y="-84" width="38" height="36" rx="6" fill={C.box} />
        <rect x="-32" y="-84" width="38" height="9" rx="4" fill={C.boxShade} />
        <text x="-13" y="-55" textAnchor="middle" fontSize="20" fontWeight="800" fill="#1d2733">
          ₹
        </text>
        <path d="M-27 -70v12" stroke={C.gloss} strokeWidth="3" strokeLinecap="round" />

        {/* rear body + gloss highlight */}
        <path d="M-22 -8Q-20 -42 18 -44H42L52 -8Z" fill={C.body} />
        <path d="M-12 -30Q-4 -40 16 -41H34" fill="none" stroke={C.gloss} strokeWidth="3" strokeLinecap="round" />
        <rect x="-24" y="-28" width="5" height="7" rx="2" fill={C.tailLight} />

        {/* seat */}
        <rect x="-6" y="-50" width="44" height="9" rx="4.5" fill={C.seat} />

        {/* floorboard */}
        <rect x="30" y="-15" width="50" height="9" rx="4" fill={C.bodyDark} />

        {/* front apron, steering column, fender */}
        <path d="M70 -8C78 -30 84 -48 92 -64L101 -60C95 -42 91 -24 87 -8Z" fill={C.body} />
        <path d="M80 -14C84 -30 88 -44 94 -56" fill="none" stroke={C.gloss} strokeWidth="2.5" strokeLinecap="round" />
        <path d="M69 -5A20 20 0 0 1 108 -3" fill="none" stroke={C.bodyDark} strokeWidth="6" strokeLinecap="round" />

        {/* handlebar + headlight with a soft beam */}
        <path d="M86 -66L106 -68" stroke={C.seat} strokeWidth="4" strokeLinecap="round" />
        <circle cx="101" cy="-56" r="9" fill={C.light} opacity="0.35" />
        <circle cx="101" cy="-56" r="4.5" fill={C.light} />

        {/* ---------- Person (bobs slightly after the scooter) ---------- */}
        <g className="rider__person">
          {/* scarf flutters from the neck */}
          <path
            className="rider__scarf"
            d="M40 -98C30 -98 22 -96 12 -102C18 -92 28 -90 40 -92Z"
            fill={C.scarf}
          />

          {/* leg + shoe */}
          <path
            d="M26 -50L54 -42L64 -18"
            fill="none"
            stroke={C.pants}
            strokeWidth="11"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <ellipse cx="68" cy="-15" rx="8" ry="4.5" fill={C.seat} />

          {/* torso + jacket shine */}
          <path d="M24 -52L42 -92" stroke={C.jacket} strokeWidth="19" strokeLinecap="round" />
          <path d="M30 -60L42 -86" stroke="rgba(255, 255, 255, 0.35)" strokeWidth="3" strokeLinecap="round" />

          {/* arm + glove */}
          <path
            d="M44 -88L66 -76L88 -68"
            fill="none"
            stroke={C.jacketShade}
            strokeWidth="7.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="90" cy="-68" r="4.5" fill={C.seat} />

          {/* head, helmet, visor + shine */}
          <circle cx="50" cy="-106" r="11.5" fill={C.skin} />
          <path d="M35.5 -106A14.5 14.5 0 0 1 64.5 -106Z" fill={C.helmet} />
          <path d="M52 -112H64A4 4 0 0 1 63 -106H52Z" fill={C.visor} />
          <path d="M40 -114Q45 -119 52 -119" fill="none" stroke={C.gloss} strokeWidth="2.5" strokeLinecap="round" />
        </g>
      </g>

      {/* Wheels last, so they sit in front of the body */}
      <Wheel x={0} />
      <Wheel x={88} />
    </g>
  );
}

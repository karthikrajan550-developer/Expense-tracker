// =====================================================================
// sceneData.js — everything the loading scene draws, as plain data.
// Change a number here to move a tree, add a cloud or reshape a hill;
// the components just loop over these arrays.
//
// The scene is 800 × 360 units. Every scrolling layer is exactly
// SCENE_WIDTH wide and is drawn twice side by side, so it can loop.
// Nothing in a layer may cross its left/right edge, and hills must start
// and end at the same height, otherwise you'd see a seam when it repeats.
// =====================================================================

export const SCENE_WIDTH = 800;
export const SCENE_HEIGHT = 360;

// Bottom of the mid mountain triangles (they overlap the hills below)
export const MOUNTAIN_BASE_Y = 252;

// Where the rear wheel's centre sits on the road
export const RIDER_POSITION = { x: 320, y: 304, scale: 1.12 };

export const COLORS = {
  skyTop: "#bfe1ff",
  skyMid: "#e4f3ff",
  skyHorizon: "#fff1df",
  sun: "#fff4c7",
  sunGlow: "#ffe3a1",
  cloud: "#ffffff",
  farMountain: "#c6d5f6",
  midMountain: "#86a3ea",
  midMountainLit: "#a5bbf3",
  snow: "#ffffff",
  backHill: "#a9e0cc",
  backPine: "#5aa98c",
  frontHill: "#78c9aa",
  treeTrunk: "#4c6f63",
  treeLight: "#9fdcc6",
  treeDark: "#4fae8b",
  verge: "#5fb894",
  road: "#465467",
  roadEdge: "#6b7a90",
  roadMark: "#f4f7fb",
  bush: "#4fae8b",
  bushLight: "#7fd0b0",
};

// The cloud-shaped frame the whole scene is clipped to
export const FRAME_PATH =
  "M60 340C20 340 6 306 18 274C30 240 10 206 38 170C70 128 132 138 162 100C202 48 302 26 382 50C448 70 482 38 548 44C626 50 666 96 696 134C728 176 786 182 792 242C798 292 784 340 740 340Z";

export const SUN = { x: 585, y: 118, r: 30 };

export const CLOUDS = [
  { x: 120, y: 98, scale: 1 },
  { x: 330, y: 66, scale: 0.8 },
  { x: 520, y: 104, scale: 1.15 },
  { x: 700, y: 74, scale: 0.7 },
];

// Distant range: low contrast, sharp ridge line
export const FAR_RANGE_PATH =
  "M0 250L60 208L120 224L190 172L260 216L330 188L400 226L470 178L550 220L620 192L700 228L760 204L800 250V360H0Z";

// Main mountains: each peak is a triangle (x = peak, w = half the base width)
export const MID_PEAKS = [
  { x: 120, y: 120, w: 120 },
  { x: 290, y: 92, w: 150 },
  { x: 470, y: 130, w: 130 },
  { x: 650, y: 100, w: 140 },
];

// Smooth hills: start and end at the same height with flat tangents (no seam)
export const BACK_HILL_PATH =
  "M0 258C80 258 150 226 260 226C370 226 420 266 530 266C640 266 720 258 800 258V360H0Z";

export const FRONT_HILL_PATH =
  "M0 286C120 286 180 262 300 262C420 262 470 292 590 292C690 292 740 286 800 286V360H0Z";

// Pines on the back hill: x, base y (just below the hill surface), height
export const BACK_PINES = [
  { x: 60, y: 258, h: 30 },
  { x: 78, y: 256, h: 22 },
  { x: 205, y: 236, h: 34 },
  { x: 228, y: 233, h: 26 },
  { x: 345, y: 238, h: 30 },
  { x: 560, y: 270, h: 28 },
  { x: 585, y: 270, h: 20 },
  { x: 745, y: 264, h: 30 },
];

// Round trees on the front hill: x, base y, scale
export const FRONT_TREES = [
  { x: 150, y: 286, scale: 1 },
  { x: 430, y: 274, scale: 1.15 },
  { x: 690, y: 294, scale: 0.9 },
];

// Bushes along the roadside
export const BUSHES = [
  { x: 70, y: 298, scale: 1 },
  { x: 255, y: 298, scale: 0.8 },
  { x: 480, y: 298, scale: 1.1 },
  { x: 640, y: 298, scale: 0.7 },
];

// Dashed centre line: 5 dashes, one every 160 units (5 × 160 = 800, so it loops)
export const ROAD_MARKS = [40, 200, 360, 520, 680];

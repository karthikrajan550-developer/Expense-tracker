// =====================================================================
// Scene.jsx — the animated landscape (parallax) with the rider.
//
// Layers, from back to front. Far layers scroll slowly, near ones fast;
// that speed difference is what gives the scene depth:
//   sky + sun (still) -> clouds -> far range -> mountains ->
//   back hill -> front hill -> road (ground speed)
//
// Each layer is drawn once in <defs> and placed twice with <use>
// (at x = 0 and x = SCENE_WIDTH). CSS slides it left by SCENE_WIDTH,
// forever, so it loops without a visible jump.
// =====================================================================
import Rider from "./Rider";
import {
  SCENE_WIDTH,
  SCENE_HEIGHT,
  MOUNTAIN_BASE_Y,
  RIDER_POSITION,
  COLORS,
  FRAME_PATH,
  SUN,
  CLOUDS,
  FAR_RANGE_PATH,
  MID_PEAKS,
  BACK_HILL_PATH,
  FRONT_HILL_PATH,
  BACK_PINES,
  FRONT_TREES,
  BUSHES,
  ROAD_MARKS,
} from "./sceneData";

// ---------- Small drawing helpers ----------

function Cloud({ x, y, scale }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`} fill={COLORS.cloud}>
      <ellipse cx="0" cy="0" rx="40" ry="11" />
      <ellipse cx="-14" cy="-7" rx="17" ry="12" />
      <ellipse cx="10" cy="-11" rx="21" ry="15" />
    </g>
  );
}

// One mountain = base triangle + lit left face + jagged snow cap
function Peak({ x, y, w }) {
  const height = MOUNTAIN_BASE_Y - y;
  const capDepth = height * 0.22;
  const capHalf = w * 0.22; // the triangle is this wide at capDepth below the peak

  return (
    <g>
      <path d={`M${x - w} ${MOUNTAIN_BASE_Y}L${x} ${y}L${x + w} ${MOUNTAIN_BASE_Y}Z`} fill={COLORS.midMountain} />
      <path
        d={`M${x - w} ${MOUNTAIN_BASE_Y}L${x} ${y}L${x + w * 0.06} ${MOUNTAIN_BASE_Y}Z`}
        fill={COLORS.midMountainLit}
      />
      <path
        d={`M${x} ${y}
            L${x + capHalf} ${y + capDepth}
            L${x + capHalf * 0.45} ${y + capDepth * 0.75}
            L${x} ${y + capDepth * 0.95}
            L${x - capHalf * 0.4} ${y + capDepth * 0.7}
            L${x - capHalf} ${y + capDepth}Z`}
        fill={COLORS.snow}
      />
    </g>
  );
}

function Pine({ x, y, h }) {
  return (
    <g fill={COLORS.backPine}>
      <path d={`M${x - h * 0.4} ${y}L${x} ${y - h * 0.62}L${x + h * 0.4} ${y}Z`} />
      <path d={`M${x - h * 0.3} ${y - h * 0.38}L${x} ${y - h}L${x + h * 0.3} ${y - h * 0.38}Z`} />
    </g>
  );
}

function RoundTree({ x, y, scale: s }) {
  return (
    <g>
      <rect x={x - 2.5 * s} y={y - 36 * s} width={5 * s} height={36 * s} rx={2 * s} fill={COLORS.treeTrunk} />
      <circle cx={x} cy={y - 48 * s} r={21 * s} fill={COLORS.treeLight} />
      <circle cx={x + 9 * s} cy={y - 40 * s} r={13 * s} fill={COLORS.treeDark} />
      <circle cx={x - 8 * s} cy={y - 56 * s} r={6 * s} fill="#ffffff" opacity="0.3" />
    </g>
  );
}

function Bush({ x, y, scale: s }) {
  return (
    <g>
      <ellipse cx={x} cy={y} rx={24 * s} ry={9 * s} fill={COLORS.bush} />
      <ellipse cx={x - 7 * s} cy={y - 5 * s} rx={11 * s} ry={7 * s} fill={COLORS.bushLight} />
    </g>
  );
}

// A scrolling layer: the same artwork twice, side by side
function Layer({ artId, speed }) {
  return (
    <g className={`scene__layer scene__layer--${speed}`}>
      <use href={`#${artId}`} />
      <use href={`#${artId}`} x={SCENE_WIDTH} />
    </g>
  );
}

// ---------- The scene ----------

export default function Scene() {
  return (
    <svg
      className="scene"
      viewBox={`0 0 ${SCENE_WIDTH} ${SCENE_HEIGHT}`}
      // CSS reads this to know how far each layer must slide
      style={{ "--scene-width": SCENE_WIDTH }}
      aria-hidden="true"
    >
      <defs>
        <clipPath id="ld-frame">
          <path d={FRAME_PATH} />
        </clipPath>

        <linearGradient id="ld-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={COLORS.skyTop} />
          <stop offset="0.55" stopColor={COLORS.skyMid} />
          <stop offset="0.75" stopColor={COLORS.skyHorizon} />
        </linearGradient>

        <radialGradient id="ld-sun-glow">
          <stop offset="0" stopColor={COLORS.sunGlow} stopOpacity="0.9" />
          <stop offset="1" stopColor={COLORS.sunGlow} stopOpacity="0" />
        </radialGradient>

        {/* Haze over the far range: distant things look paler (atmospheric perspective) */}
        <linearGradient id="ld-haze" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0.45" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="0.72" stopColor="#ffffff" stopOpacity="0.55" />
        </linearGradient>

        {/* ----- Layer artwork (each exactly SCENE_WIDTH wide) ----- */}
        <g id="ld-clouds">
          {CLOUDS.map((cloud) => (
            <Cloud key={cloud.x} {...cloud} />
          ))}
        </g>

        <g id="ld-far">
          <path d={FAR_RANGE_PATH} fill={COLORS.farMountain} />
        </g>

        <g id="ld-mid">
          <rect x="0" y={MOUNTAIN_BASE_Y - 14} width={SCENE_WIDTH} height="120" fill={COLORS.midMountain} />
          {MID_PEAKS.map((peak) => (
            <Peak key={peak.x} {...peak} />
          ))}
        </g>

        <g id="ld-back">
          <path d={BACK_HILL_PATH} fill={COLORS.backHill} />
          {BACK_PINES.map((pine) => (
            <Pine key={pine.x} {...pine} />
          ))}
        </g>

        <g id="ld-front">
          <path d={FRONT_HILL_PATH} fill={COLORS.frontHill} />
          {FRONT_TREES.map((tree) => (
            <RoundTree key={tree.x} {...tree} />
          ))}
        </g>

        <g id="ld-ground">
          <rect x="0" y="292" width={SCENE_WIDTH} height="10" fill={COLORS.verge} />
          <rect x="0" y="300" width={SCENE_WIDTH} height="60" fill={COLORS.road} />
          <rect x="0" y="300" width={SCENE_WIDTH} height="3" fill={COLORS.roadEdge} />
          {ROAD_MARKS.map((x) => (
            <rect key={x} x={x} y="326" width="56" height="4" rx="2" fill={COLORS.roadMark} opacity="0.85" />
          ))}
          {BUSHES.map((bush) => (
            <Bush key={bush.x} {...bush} />
          ))}
        </g>
      </defs>

      <g clipPath="url(#ld-frame)">
        {/* Sky and sun don't scroll: they are "infinitely" far away */}
        <rect width={SCENE_WIDTH} height={SCENE_HEIGHT} fill="url(#ld-sky)" />
        <circle className="scene__sun-glow" cx={SUN.x} cy={SUN.y} r={SUN.r * 3} fill="url(#ld-sun-glow)" />
        <circle cx={SUN.x} cy={SUN.y} r={SUN.r} fill={COLORS.sun} />

        <Layer artId="ld-clouds" speed="clouds" />

        {/* Birds glide across the sky and flap */}
        <g className="scene__birds" fill="none" stroke="#5b6f8f" strokeWidth="1.8" strokeLinecap="round">
          <g transform="translate(0 92)">
            <path className="bird" d="M0 0Q5 -5 10 0Q15 -5 20 0" />
          </g>
          <g transform="translate(26 80) scale(0.75)">
            <path className="bird bird--late" d="M0 0Q5 -5 10 0Q15 -5 20 0" />
          </g>
        </g>

        <Layer artId="ld-far" speed="far" />
        <rect y="150" width={SCENE_WIDTH} height="120" fill="url(#ld-haze)" />
        <Layer artId="ld-mid" speed="mid" />
        <Layer artId="ld-back" speed="back" />
        <Layer artId="ld-front" speed="front" />
        <Layer artId="ld-ground" speed="ground" />

        {/* The outer group rides off at the end; the inner one positions the rider */}
        <g className="scene__rider">
          <g transform={`translate(${RIDER_POSITION.x} ${RIDER_POSITION.y}) scale(${RIDER_POSITION.scale})`}>
            <Rider />
          </g>
        </g>
      </g>

      {/* Glass edge around the frame */}
      <path d={FRAME_PATH} fill="none" stroke="rgba(255, 255, 255, 0.9)" strokeWidth="3" />
    </svg>
  );
}

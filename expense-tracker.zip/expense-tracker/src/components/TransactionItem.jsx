// =====================================================================
// TransactionItem.jsx — one row: title, category, amount, actions.
// (The date is shown once in the group heading above the rows.)
//
// Local state:
//   isConfirming -> shows "Yes, delete / Keep"
//   isRemoving   -> plays the slide-out + collapse animation; when the
//                   animation ends we ask App to really delete the row.
//                   (With reduced motion there is no animation, so we
//                   delete straight away. A fallback timer makes sure a
//                   row can never get stuck if the event doesn't fire.)
// =====================================================================
import { useEffect, useState } from "react";
import { CATEGORY_COLORS } from "../data/constants";
import { formatCurrency } from "../utils/format";
import { prefersReducedMotion } from "../utils/motion";

export default function TransactionItem({ transaction, isEditing, isHighlighted, onEdit, onDelete }) {
  const { id, title, amount, type, category } = transaction; // destructuring
  const [isConfirming, setIsConfirming] = useState(false);
  const [isRemoving, setIsRemoving] = useState(false);

  const sign = type === "credit" ? "+" : "−";

  // Safety net: delete anyway shortly after the animation should have ended
  useEffect(() => {
    if (!isRemoving) return undefined;
    const fallback = setTimeout(() => onDelete(id), 800);
    return () => clearTimeout(fallback);
  }, [isRemoving, id, onDelete]);

  function confirmDelete() {
    if (prefersReducedMotion()) {
      onDelete(id);
    } else {
      setIsRemoving(true);
    }
  }

  // Only react to the row's own exit animation (not ripples etc. inside it)
  function handleAnimationEnd(event) {
    if (event.animationName === "row-out") onDelete(id);
  }

  const classNames = [
    "transaction",
    isEditing && "transaction--editing",
    isHighlighted && "transaction--highlight",
    isRemoving && "transaction--removing",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <li
      className={classNames}
      style={{ "--category-color": CATEGORY_COLORS[category] }}
      onAnimationEnd={handleAnimationEnd}
    >
      <div className="transaction__info">
        <p className="transaction__title">{title}</p>
        <p className="transaction__category">{category}</p>
      </div>

      <p className={`transaction__amount transaction__amount--${type}`}>
        {sign}
        {formatCurrency(amount)}
      </p>

      <div className="transaction__actions">
        {isConfirming ? (
          <>
            <button type="button" className="btn btn--small btn--danger-solid" onClick={confirmDelete} disabled={isRemoving}>
              Yes, delete
            </button>
            <button type="button" className="btn btn--small" onClick={() => setIsConfirming(false)} disabled={isRemoving}>
              Keep
            </button>
          </>
        ) : (
          <>
            <button type="button" className="btn btn--small" onClick={() => onEdit(transaction)}>
              Edit
            </button>
            <button type="button" className="btn btn--small btn--danger" onClick={() => setIsConfirming(true)}>
              Delete
            </button>
          </>
        )}
      </div>
    </li>
  );
}

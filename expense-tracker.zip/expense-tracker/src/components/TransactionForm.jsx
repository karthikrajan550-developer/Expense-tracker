// =====================================================================
// TransactionForm.jsx — one form used for both CREATE and UPDATE.
//   editingTransaction === null  -> "Add" mode
//   editingTransaction === {...} -> "Edit" mode (inputs pre-filled)
//
// Validation: title, amount, category and date are all required.
// Each missing field shows its own message under the input.
// =====================================================================
import { useState, useEffect } from "react";
import { CATEGORIES, TRANSACTION_TYPES, TYPE_LABELS } from "../data/constants";
import { getToday } from "../utils/format";
import { AddNoteIcon } from "./Icons";

// category starts empty so the user must choose one
function getEmptyForm() {
  return { title: "", amount: "", type: "debit", category: "", date: getToday() };
}

// Order matters: the first field with an error gets focus
const FIELD_ORDER = ["title", "amount", "category", "date"];

export default function TransactionForm({ editingTransaction, onAdd, onUpdate, onCancel }) {
  // Controlled form: every input's value comes from this state object
  const [form, setForm] = useState(getEmptyForm);
  const [errors, setErrors] = useState({});

  const isEditing = editingTransaction !== null;

  // Fill the form when editing starts, reset it when editing ends.
  // Every reset calls getEmptyForm(), so the date goes back to TODAY.
  useEffect(() => {
    if (editingTransaction) {
      setForm({ ...editingTransaction, amount: String(editingTransaction.amount) });
    } else {
      setForm(getEmptyForm());
    }
    setErrors({});
  }, [editingTransaction]);

  // One handler for every input, using the input's `name` attribute
  function handleChange(event) {
    const { name, value } = event.target;

    // Changing the type clears the category, because the old one
    // (e.g. "Food") doesn't exist in the other type's list
    if (name === "type") {
      setForm((prev) => ({ ...prev, type: value, category: "" }));
      return;
    }

    setForm((prev) => ({ ...prev, [name]: value }));

    // Remove this field's error as soon as the user starts fixing it
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  }

  // Returns an object like { amount: "Please enter the amount." }
  // An empty object means everything is valid.
  function validate() {
    const newErrors = {};

    if (form.title.trim() === "") {
      newErrors.title = "Please enter a title.";
    }

    if (form.amount === "") {
      newErrors.amount = "Please enter the amount.";
    } else if (Number(form.amount) <= 0) {
      newErrors.amount = "Amount must be greater than 0.";
    }

    if (form.category === "") {
      newErrors.category = "Please select a category.";
    }

    if (form.date === "") {
      newErrors.date = "Please select a date.";
    } else if (form.date > getToday()) {
      newErrors.date = "Date can't be in the future.";
    }

    return newErrors;
  }

  function handleSubmit(event) {
    event.preventDefault(); // stop the browser from reloading the page

    const newErrors = validate();
    setErrors(newErrors);

    // Stop here if anything is invalid, and move the cursor to the first problem
    const firstInvalid = FIELD_ORDER.find((field) => newErrors[field]);
    if (firstInvalid) {
      document.getElementById(firstInvalid)?.focus();
      return;
    }

    const transaction = { ...form, title: form.title.trim(), amount: Number(form.amount) };

    if (isEditing) {
      onUpdate(transaction);
    } else {
      onAdd(transaction);
      setForm(getEmptyForm());
    }
  }

  // Small helper so each input gets the same error attributes
  function errorProps(field) {
    return {
      "aria-invalid": Boolean(errors[field]),
      "aria-describedby": errors[field] ? `${field}-error` : undefined,
    };
  }

  return (
    <form className={`panel form ${isEditing ? "form--editing" : ""}`} onSubmit={handleSubmit} noValidate>
      <h2 className="heading-with-icon">
        <AddNoteIcon size={28} />
        Transaction details
      </h2>

      {/* Credit / Debit toggle built from real radio buttons */}
      <fieldset className="type-toggle">
        <legend>Type</legend>
        {TRANSACTION_TYPES.map((type) => (
          <label
            key={type}
            className={`type-toggle__option type-toggle__option--${type} ${form.type === type ? "is-active" : ""}`}
          >
            <input type="radio" name="type" value={type} checked={form.type === type} onChange={handleChange} />
            {TYPE_LABELS[type]}
            <small>{type === "credit" ? "Money in" : "Money out"}</small>
          </label>
        ))}
      </fieldset>

      <div className="field">
        <label htmlFor="title">Title</label>
        <input
          id="title"
          name="title"
          type="text"
          placeholder={form.type === "credit" ? "e.g. Salary" : "e.g. Groceries"}
          value={form.title}
          onChange={handleChange}
          {...errorProps("title")}
        />
        {errors.title && <p className="field__error" id="title-error">{errors.title}</p>}
      </div>

      <div className="field-row">
        <div className="field">
          <label htmlFor="amount">Amount (₹)</label>
          <input
            id="amount"
            name="amount"
            type="number"
            min="0"
            step="0.01"
            placeholder="0"
            value={form.amount}
            onChange={handleChange}
            {...errorProps("amount")}
          />
          {errors.amount && <p className="field__error" id="amount-error">{errors.amount}</p>}
        </div>

        <div className="field">
          <label htmlFor="date">Date</label>
          <input
            id="date"
            name="date"
            type="date"
            max={getToday()}
            value={form.date}
            onChange={handleChange}
            {...errorProps("date")}
          />
          {errors.date && <p className="field__error" id="date-error">{errors.date}</p>}
        </div>
      </div>

      <div className="field">
        <label htmlFor="category">Category</label>
        <select id="category" name="category" value={form.category} onChange={handleChange} {...errorProps("category")}>
          {/* Empty first option = nothing chosen yet */}
          <option value="">Select a category</option>
          {CATEGORIES[form.type].map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
        {errors.category && <p className="field__error" id="category-error">{errors.category}</p>}
      </div>

      <div className="form__actions">
        <button type="submit" className="btn btn--primary">
          {isEditing ? "Save changes" : `Add ${TYPE_LABELS[form.type].toLowerCase()}`}
        </button>
        {isEditing && (
          <button type="button" className="btn" onClick={onCancel}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}

// =====================================================================
// Analytics.jsx — lets the user pick WHAT to see and HOW to see it.
//   dataView  -> which numbers ("overview", "spending", "income")
//   chartType -> which chart ("bar" or "pie")
// These choices only matter here, so this component keeps its own state.
// The transactions it receives are already filtered by the selected date.
// =====================================================================
import { useState } from "react";
import BarChart from "./charts/BarChart";
import PieChart from "./charts/PieChart";
import { getChartData } from "../utils/calculations";
import { ChartIcon } from "./Icons";

const DATA_VIEWS = [
  { id: "overview", label: "Credit vs debit" },
  { id: "spending", label: "Spending by category" },
  { id: "income", label: "Income by category" },
];

const CHART_TYPES = [
  { id: "bar", label: "Bar" },
  { id: "pie", label: "Pie" },
];

export default function Analytics({ transactions }) {
  const [dataView, setDataView] = useState("overview");
  const [chartType, setChartType] = useState("bar");

  const chartData = getChartData(transactions, dataView);

  return (
    <section className="panel" aria-labelledby="analytics-heading">
      <div className="panel__header">
        <h2 id="analytics-heading" className="heading-with-icon">
          <ChartIcon size={28} />
          Analytics
        </h2>

        <div className="analytics-controls">
          <label className="visually-hidden" htmlFor="data-view">
            Data to show
          </label>
          <select id="data-view" value={dataView} onChange={(event) => setDataView(event.target.value)}>
            {DATA_VIEWS.map((view) => (
              <option key={view.id} value={view.id}>
                {view.label}
              </option>
            ))}
          </select>

          {/* --index tells CSS where to slide the white pill */}
          <div
            className="segmented"
            role="group"
            aria-label="Chart type"
            style={{ "--index": CHART_TYPES.findIndex((type) => type.id === chartType) }}
          >
            <span className="segmented__indicator" aria-hidden="true" />
            {CHART_TYPES.map((type) => (
              <button
                key={type.id}
                type="button"
                className={`segmented__option ${chartType === type.id ? "is-active" : ""}`}
                aria-pressed={chartType === type.id}
                onClick={() => setChartType(type.id)}
              >
                {type.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Conditional rendering: empty message, bar chart, or pie chart */}
      {chartData.length === 0 ? (
        <p className="chart-empty">No data for this view. Pick another date or add a transaction.</p>
      ) : chartType === "bar" ? (
        <BarChart data={chartData} />
      ) : (
        <PieChart data={chartData} />
      )}
    </section>
  );
}

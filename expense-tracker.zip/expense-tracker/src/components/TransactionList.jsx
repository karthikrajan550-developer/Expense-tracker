// =====================================================================
// TransactionList.jsx — shows transactions grouped under date headings,
// in the order chosen in the filter bar (newest or oldest first).
// =====================================================================
import TransactionItem from "./TransactionItem";
import { groupByDate } from "../utils/calculations";
import { formatCurrency, formatDayHeading } from "../utils/format";
import { ReceiptIcon } from "./Icons";

export default function TransactionList({
  transactions,
  hasAnyTransactions,
  isDateSelected,
  onSelectDate,
  editingId,
  highlightId,
  onEdit,
  onDelete,
}) {
  if (transactions.length === 0) {
    let message = "No transactions yet. Add your first one with the form.";
    if (hasAnyTransactions) {
      message = isDateSelected
        ? "No transactions on this date. Pick another date or show all dates."
        : "No transactions match these filters. Try a different search or category.";
    }
    return (
      <div className="empty-state">
        <ReceiptIcon size={56} />
        <p>{message}</p>
      </div>
    );
  }

  // transactions are already sorted, so groups come out in date order too
  const groups = groupByDate(transactions);

  return (
    <div className="date-groups">
      {groups.map((group) => (
        <section className="date-group" key={group.date} aria-label={formatDayHeading(group.date)}>
          <h3 className="date-group__heading">
            {/* When showing all dates, a heading can be clicked to see only that date */}
            {isDateSelected ? (
              <time dateTime={group.date}>{formatDayHeading(group.date)}</time>
            ) : (
              <button
                type="button"
                className="date-group__button"
                onClick={() => onSelectDate(group.date)}
                title="Show only this date"
              >
                <time dateTime={group.date}>{formatDayHeading(group.date)}</time>
              </button>
            )}
            {group.spent > 0 && <span>Spent {formatCurrency(group.spent)}</span>}
          </h3>

          <ul className="transaction-list">
            {group.items.map((transaction) => (
              // `key` lets React track each item between renders
              <TransactionItem
                key={transaction.id}
                transaction={transaction}
                isEditing={transaction.id === editingId}
                isHighlighted={transaction.id === highlightId}
                onEdit={onEdit}
                onDelete={onDelete}
              />
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}

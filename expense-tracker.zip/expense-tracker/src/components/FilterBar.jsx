// =====================================================================
// FilterBar.jsx — search box, type chips, category and date-order dropdowns.
// It doesn't own the filters; it reports changes to App via a prop.
// =====================================================================
import { CATEGORIES } from "../data/constants";

const SORT_OPTIONS = [
  { id: "newest", label: "Newest first" },
  { id: "oldest", label: "Oldest first" },
];

const TYPE_OPTIONS = [
  { id: "all", label: "All" },
  { id: "credit", label: "Credit" },
  { id: "debit", label: "Debit" },
];

export default function FilterBar({ filters, onFiltersChange }) {
  // Show only the categories that belong to the selected type
  const categoryOptions =
    filters.type === "all" ? [...CATEGORIES.credit, ...CATEGORIES.debit] : CATEGORIES[filters.type];

  function updateFilter(name, value) {
    const nextFilters = { ...filters, [name]: value };
    if (name === "type") nextFilters.category = "all"; // old category may not exist for the new type
    onFiltersChange(nextFilters);
  }

  return (
    <div className="filter-bar">
      <input
        type="search"
        placeholder="Search by title"
        aria-label="Search transactions by title"
        value={filters.search}
        onChange={(event) => updateFilter("search", event.target.value)}
      />

      <div className="filter-bar__row">
        <div className="chips" role="group" aria-label="Filter by type">
          {TYPE_OPTIONS.map((option) => (
            <button
              key={option.id}
              type="button"
              className={`chip ${filters.type === option.id ? "is-active" : ""}`}
              aria-pressed={filters.type === option.id}
              onClick={() => updateFilter("type", option.id)}
            >
              {option.label}
            </button>
          ))}
        </div>

        <div className="filter-bar__selects">
          <select
            aria-label="Filter by category"
            value={filters.category}
            onChange={(event) => updateFilter("category", event.target.value)}
          >
            <option value="all">All categories</option>
            {categoryOptions.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>

          <select
            aria-label="Sort by date"
            value={filters.sortOrder}
            onChange={(event) => updateFilter("sortOrder", event.target.value)}
          >
            {SORT_OPTIONS.map((option) => (
              <option key={option.id} value={option.id}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}

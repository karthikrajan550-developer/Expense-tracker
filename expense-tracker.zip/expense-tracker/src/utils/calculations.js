// =====================================================================
// calculations.js — pure functions (no React, no side effects).
// Input: an array of transactions. Output: new numbers or arrays.
// Keeping maths here makes components short and easy to read.
// =====================================================================
import { CATEGORIES, CATEGORY_COLORS, TYPE_COLORS } from "../data/constants";

// Adds up the `amount` of every transaction in the list
export function sumAmounts(transactions) {
  return transactions.reduce((sum, item) => sum + item.amount, 0);
}

// Returns { credit, debit, balance } for the dashboard
export function getTotals(transactions) {
  const credit = sumAmounts(transactions.filter((item) => item.type === "credit"));
  const debit = sumAmounts(transactions.filter((item) => item.type === "debit"));
  return { credit, debit, balance: credit - debit };
}

// Total per category for one type, e.g. how much was spent on Food, Bills...
// Returns chart-ready data: [{ label, value, color }]
export function getCategoryTotals(transactions, type) {
  return CATEGORIES[type]
    .map((category) => ({
      label: category,
      value: sumAmounts(
        transactions.filter((item) => item.type === type && item.category === category)
      ),
      color: CATEGORY_COLORS[category],
    }))
    .filter((entry) => entry.value > 0) // hide empty categories
    .sort((a, b) => b.value - a.value); // biggest first
}

// Builds the data for whichever analytics view the user picked
export function getChartData(transactions, view) {
  if (view === "spending") return getCategoryTotals(transactions, "debit");
  if (view === "income") return getCategoryTotals(transactions, "credit");

  // Default view: "overview" (credit vs debit)
  const { credit, debit } = getTotals(transactions);
  return [
    { label: "Credit", value: credit, color: TYPE_COLORS.credit },
    { label: "Debit", value: debit, color: TYPE_COLORS.debit },
  ].filter((entry) => entry.value > 0);
}

// Keeps only the transactions on one date ("YYYY-MM-DD").
// If no date is selected (null), returns everything.
export function filterByDate(transactions, selectedDate) {
  if (!selectedDate) return transactions;
  return transactions.filter((item) => item.date === selectedDate);
}

// Sorts by date. Two transactions on the same date are ordered by id,
// and ids come from Date.now(), so the one added later counts as newer.
//   order = "newest" -> latest date first
//   order = "oldest" -> earliest date first
export function sortByDate(transactions, order) {
  return [...transactions].sort((a, b) => {
    const difference = a.date.localeCompare(b.date) || Number(a.id) - Number(b.id);
    return order === "oldest" ? difference : -difference;
  });
}

// Applies the type, category and search filters, then sorts by date
export function filterTransactions(transactions, filters) {
  const searchText = filters.search.trim().toLowerCase();

  const filtered = transactions
    .filter((item) => filters.type === "all" || item.type === filters.type)
    .filter((item) => filters.category === "all" || item.category === filters.category)
    .filter((item) => item.title.toLowerCase().includes(searchText));

  return sortByDate(filtered, filters.sortOrder);
}

// Groups an already-sorted list by date, keeping the order:
// [{ date: "2026-10-27", items: [...], spent: 210 }, ...]
export function groupByDate(transactions) {
  const groups = [];

  transactions.forEach((item) => {
    const lastGroup = groups[groups.length - 1];
    if (lastGroup && lastGroup.date === item.date) {
      lastGroup.items.push(item);
    } else {
      groups.push({ date: item.date, items: [item] });
    }
  });

  return groups.map((group) => ({
    ...group,
    spent: sumAmounts(group.items.filter((item) => item.type === "debit")),
  }));
}

// =====================================================================
// storage.js — reads and writes transactions in localStorage.
// localStorage only stores strings, so we use JSON.stringify / JSON.parse.
// =====================================================================
import { STORAGE_KEY, SAMPLE_TRANSACTIONS } from "../data/constants";

export function loadTransactions() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved !== null ? JSON.parse(saved) : SAMPLE_TRANSACTIONS;
  } catch (error) {
    console.error("Could not read saved transactions:", error);
    return SAMPLE_TRANSACTIONS;
  }
}

export function saveTransactions(transactions) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
  } catch (error) {
    console.error("Could not save transactions:", error);
  }
}

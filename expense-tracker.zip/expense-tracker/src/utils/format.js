// =====================================================================
// format.js — small helpers that turn raw values into display text.
// =====================================================================

// 2999 -> "₹2,999"
export function formatCurrency(amount) {
  return amount.toLocaleString("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
}

// Short form for chart labels: 950 -> "₹950", 52000 -> "₹52K", 150000 -> "₹1.5L"
export function formatCompactCurrency(amount) {
  if (amount >= 100000) return `₹${round1(amount / 100000)}L`; // lakh
  if (amount >= 1000) return `₹${round1(amount / 1000)}K`; // thousand
  return `₹${round1(amount)}`;
}

// Rounds to 1 decimal place and drops ".0" (52.0 -> 52, 24.32 -> 24.3)
function round1(value) {
  return Math.round(value * 10) / 10;
}

// "2026-10-26" -> "26 Oct 2026"
export function formatDate(dateString) {
  const date = new Date(dateString + "T00:00:00");
  return date.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

// Converts a JS Date into "YYYY-MM-DD" in the user's LOCAL time zone
// (toISOString alone uses UTC, which can give yesterday's date in India before 5:30 AM)
function toInputDate(date) {
  const offset = date.getTimezoneOffset() * 60000;
  return new Date(date - offset).toISOString().slice(0, 10);
}

// Today's date as "YYYY-MM-DD" (the format <input type="date"> uses).
// Called every time the form is created or reset, so it is always the current date.
export function getToday() {
  return toInputDate(new Date());
}

// A date some days in the past, e.g. getDateDaysAgo(1) = yesterday
export function getDateDaysAgo(days) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return toInputDate(date);
}

// Heading for a group of transactions in the list:
// "Today", "Yesterday", or "Monday, 26 Oct 2026"
export function formatDayHeading(dateString) {
  if (dateString === getToday()) return "Today";
  if (dateString === getDateDaysAgo(1)) return "Yesterday";

  const date = new Date(dateString + "T00:00:00");
  const weekday = date.toLocaleDateString("en-IN", { weekday: "long" });
  return `${weekday}, ${formatDate(dateString)}`;
}

// "Good morning" / "Good afternoon" / "Good evening" for the current time
export function getGreeting(date = new Date()) {
  const hour = date.getHours();
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

// "Tuesday, 27 October 2026"
// Built from parts so the punctuation is the same in every browser
export function formatLongDate(date = new Date()) {
  const weekday = date.toLocaleDateString("en-IN", { weekday: "long" });
  const month = date.toLocaleDateString("en-IN", { month: "long" });
  return `${weekday}, ${date.getDate()} ${month} ${date.getFullYear()}`;
}

// =====================================================================
// motion.js — shared helpers for animation.
// =====================================================================

// Easing curves: take t from 0 to 1, return the eased value from 0 to 1
export const easeOutQuad = (t) => 1 - (1 - t) * (1 - t);
export const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

// True if the user asked their device for less motion
export function prefersReducedMotion() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

// True for a mouse/trackpad (not touch screens)
export function hasFinePointer() {
  return window.matchMedia("(hover: hover) and (pointer: fine)").matches;
}

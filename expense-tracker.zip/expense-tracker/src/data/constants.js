// =====================================================================
// constants.js — fixed values used across the app.
// Change a category name or colour here and the whole app updates.
// =====================================================================

import { getDateDaysAgo } from "../utils/format";

// Credit = money coming IN, Debit = money going OUT
export const TRANSACTION_TYPES = ["debit", "credit"];

export const TYPE_LABELS = {
  credit: "Credit",
  debit: "Debit",
};

export const TYPE_COLORS = {
  credit: "#1f7a4d",
  debit: "#c0392b",
};

// Each type has its own list of categories
export const CATEGORIES = {
  credit: ["Salary", "Freelance", "Gift", "Refund", "Other income"],
  debit: ["Food", "Travel", "Bills", "Shopping", "Health", "Other"],
};

// Colour for each category (used in charts and list items)
export const CATEGORY_COLORS = {
  Salary: "#1f7a4d",
  Freelance: "#3aa17e",
  Gift: "#7fc8a9",
  Refund: "#2b8a9e",
  "Other income": "#9bb5a8",
  Food: "#e08e2b",
  Travel: "#2f7dbf",
  Bills: "#7a5ac8",
  Shopping: "#d2557a",
  Health: "#c9a227",
  Other: "#7d8a91",
};

// Key used to save data in the browser's localStorage
export const STORAGE_KEY = "expense-tracker-transactions";

// Sample data shown the very first time the app opens (helps during a demo).
// Dates are relative to today, so the demo always looks current.
export const SAMPLE_TRANSACTIONS = [
  { id: "1", title: "Monthly salary", amount: 52000, type: "credit", category: "Salary", date: getDateDaysAgo(26) },
  { id: "2", title: "House rent", amount: 15000, type: "debit", category: "Bills", date: getDateDaysAgo(24) },
  { id: "3", title: "Groceries", amount: 3200, type: "debit", category: "Food", date: getDateDaysAgo(15) },
  { id: "4", title: "Website project", amount: 8000, type: "credit", category: "Freelance", date: getDateDaysAgo(12) },
  { id: "5", title: "Pharmacy", amount: 320, type: "debit", category: "Health", date: getDateDaysAgo(9) },
  { id: "6", title: "Running shoes", amount: 2999, type: "debit", category: "Shopping", date: getDateDaysAgo(7) },
  { id: "7", title: "Electricity bill", amount: 1850, type: "debit", category: "Bills", date: getDateDaysAgo(5) },
  { id: "8", title: "Metro card recharge", amount: 500, type: "debit", category: "Travel", date: getDateDaysAgo(2) },
  { id: "9", title: "Lunch with team", amount: 450, type: "debit", category: "Food", date: getDateDaysAgo(1) },
  { id: "10", title: "Morning coffee", amount: 120, type: "debit", category: "Food", date: getDateDaysAgo(0) },
  { id: "11", title: "Auto to office", amount: 90, type: "debit", category: "Travel", date: getDateDaysAgo(0) },
];

// The app's pages (tabs), used by the router, header and mobile tab bar
export const PAGES = [
  { id: "dashboard", label: "Dashboard", title: "Dashboard" },
  { id: "transactions", label: "Transactions", title: "Transactions" },
  { id: "add", label: "Add expense", title: "Add expense" },
];

export const PAGE_IDS = PAGES.map((page) => page.id);
export const DEFAULT_PAGE = "dashboard";

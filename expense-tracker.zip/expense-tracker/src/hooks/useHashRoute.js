// =====================================================================
// useHashRoute.js — a tiny router for a few pages, using the URL hash:
//   #/dashboard   #/transactions   #/add
//
// Why the hash? It changes the URL without reloading the page and needs
// no server setup, so it works anywhere (even opening index.html directly).
//   - refresh keeps you on the same page (read from the hash on start)
//   - browser Back / Forward work (we listen to "hashchange")
//
// React state is the source of truth; the hash just mirrors it. Writing
// the hash is wrapped in try/catch, so the app still works in embedded
// previews that don't allow changing the URL.
//
// In a bigger app you'd use React Router; this is the same idea in ~40 lines.
// =====================================================================
import { useCallback, useEffect, useState } from "react";

function readRoute(routeIds, fallback) {
  const id = window.location.hash.replace(/^#\/?/, ""); // "#/add" -> "add"
  return routeIds.includes(id) ? id : fallback;
}

export default function useHashRoute(routeIds, fallback) {
  const [route, setRoute] = useState(() => readRoute(routeIds, fallback));

  // Back / Forward buttons (or a typed URL) change the hash -> follow it
  useEffect(() => {
    const handleHashChange = () => setRoute(readRoute(routeIds, fallback));
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, [routeIds, fallback]);

  const navigate = useCallback((id) => {
    setRoute(id);
    try {
      if (window.location.hash !== `#/${id}`) window.location.hash = `/${id}`;
    } catch {
      // URL can't be changed here (e.g. a sandboxed preview): state still works
    }
  }, []);

  return [route, navigate];
}

// =====================================================================
// useProgress.js — a number that goes from 0 to 1 over `duration` ms.
// Uses requestAnimationFrame, so it updates in step with the screen
// (about 60 times a second) and pauses when the tab is hidden.
//
// The value is eased ("ease-out quad"): a little faster at first and
// gently slowing, but still moving right up to 100%.
// =====================================================================
import { useEffect, useState } from "react";
import { easeOutQuad } from "../utils/motion";

export default function useProgress(duration) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let frameId;
    const start = performance.now();

    function tick(now) {
      const elapsed = Math.min((now - start) / duration, 1); // 0 → 1
      setProgress(easeOutQuad(elapsed));
      if (elapsed < 1) frameId = requestAnimationFrame(tick);
    }

    frameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameId); // stop if unmounted early
  }, [duration]);

  return progress;
}

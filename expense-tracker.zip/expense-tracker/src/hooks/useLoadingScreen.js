// =====================================================================
// useLoadingScreen.js — a custom hook for the loading screen.
// It moves through three stages, using two timers:
//
//   "loading" ──(LOADING_TIME)──► "leaving" ──(FADE_TIME)──► "done"
//   scene playing                 screen fades out           screen removed
//
// A custom hook is just a function starting with "use" that uses other
// hooks. It keeps this timing logic out of App.jsx.
// =====================================================================
import { useEffect, useState } from "react";

export const LOADING_TIME = 2200; // how long the loading scene shows (ms)
export const FADE_TIME = 650; // rider rides off + screen fades (ms)

export default function useLoadingScreen() {
  const [stage, setStage] = useState("loading");

  useEffect(() => {
    const leaveTimer = setTimeout(() => setStage("leaving"), LOADING_TIME);
    const doneTimer = setTimeout(() => setStage("done"), LOADING_TIME + FADE_TIME);

    // Cleanup: cancel both timers if the component unmounts early
    return () => {
      clearTimeout(leaveTimer);
      clearTimeout(doneTimer);
    };
  }, []); // [] = run once, when the app first opens (or the page is refreshed)

  return stage;
}

// =====================================================================
// useScrolled.js — true once the page has scrolled past `offset` px.
// The header uses it to switch to a stronger glass + shadow.
// =====================================================================
import { useEffect, useState } from "react";

export default function useScrolled(offset = 8) {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const update = () => setIsScrolled(window.scrollY > offset);
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, [offset]);

  return isScrolled;
}

// =====================================================================
// useInteractiveEffects.js — pointer effects for the whole app, set up
// ONCE with "event delegation": a few listeners on `document` instead of
// one per button or card. New elements get the effects automatically.
//
//   ripple    -> a circle spreads from where you press a button
//   spotlight -> panels glow softly under the cursor
//   tilt      -> dashboard cards tilt in 3D toward the cursor, with glare
//
// The effects only pass the pointer position to CSS through custom
// properties (--mx, --my, --rx, --ry); the look lives in index.css.
// Movement is throttled with requestAnimationFrame (max once per frame).
// =====================================================================
import { useEffect } from "react";
import { prefersReducedMotion, hasFinePointer } from "../utils/motion";

const RIPPLE_SELECTOR = ".btn, .chip, .segmented__option, .type-toggle__option, .nav-link, .tab-bar__item";
const SPOTLIGHT_SELECTOR = ".panel";
const TILT_SELECTOR = ".stat";
const MAX_TILT_DEGREES = 8;

// Stores the pointer position inside `element` as percentages (0–100)
function setPointerPosition(element, event) {
  const rect = element.getBoundingClientRect();
  const x = (event.clientX - rect.left) / rect.width;
  const y = (event.clientY - rect.top) / rect.height;
  element.style.setProperty("--mx", `${x * 100}%`);
  element.style.setProperty("--my", `${y * 100}%`);
  return { x, y };
}

function addRipple(event) {
  const target = event.target.closest(RIPPLE_SELECTOR);
  if (!target) return;

  const rect = target.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height) * 2;
  const ripple = document.createElement("span");
  ripple.className = "ripple";
  ripple.style.width = `${size}px`;
  ripple.style.height = `${size}px`;
  ripple.style.left = `${event.clientX - rect.left - size / 2}px`;
  ripple.style.top = `${event.clientY - rect.top - size / 2}px`;

  target.appendChild(ripple);
  ripple.addEventListener("animationend", () => ripple.remove());
}

export default function useInteractiveEffects() {
  useEffect(() => {
    if (prefersReducedMotion()) return undefined;

    const canHover = hasFinePointer();
    let frameId = null;
    let lastEvent = null;

    function applyPointerEffects() {
      frameId = null;
      const event = lastEvent;

      const panel = event.target.closest?.(SPOTLIGHT_SELECTOR);
      if (panel) setPointerPosition(panel, event);

      const card = event.target.closest?.(TILT_SELECTOR);
      if (card) {
        const { x, y } = setPointerPosition(card, event);
        card.style.setProperty("--ry", `${(x - 0.5) * MAX_TILT_DEGREES * 2}deg`);
        card.style.setProperty("--rx", `${(0.5 - y) * MAX_TILT_DEGREES * 2}deg`);
      }
    }

    function handlePointerMove(event) {
      lastEvent = event;
      if (frameId === null) frameId = requestAnimationFrame(applyPointerEffects);
    }

    // When the pointer leaves a card, let it settle back flat
    function handlePointerOut(event) {
      const card = event.target.closest?.(TILT_SELECTOR);
      if (card && !card.contains(event.relatedTarget)) {
        card.style.setProperty("--rx", "0deg");
        card.style.setProperty("--ry", "0deg");
      }
    }

    document.addEventListener("pointerdown", addRipple);
    if (canHover) {
      document.addEventListener("pointermove", handlePointerMove, { passive: true });
      document.addEventListener("pointerout", handlePointerOut);
    }

    // Cleanup: remove every listener and any pending frame
    return () => {
      document.removeEventListener("pointerdown", addRipple);
      document.removeEventListener("pointermove", handlePointerMove);
      document.removeEventListener("pointerout", handlePointerOut);
      if (frameId !== null) cancelAnimationFrame(frameId);
    };
  }, []);
}

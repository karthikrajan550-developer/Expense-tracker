// =====================================================================
// AddPage.jsx — the form on its own page, centred.
// The same page is used for adding and for editing (Edit on a row
// opens this page with the form pre-filled).
// =====================================================================
import PageHeader from "../components/PageHeader";
import TransactionForm from "../components/TransactionForm";

export default function AddPage({ editingTransaction, onAdd, onUpdate, onCancel, titleRef }) {
  const isEditing = editingTransaction !== null;

  return (
    <>
      <PageHeader
        eyebrow={isEditing ? "Edit" : "New entry"}
        title={isEditing ? "Edit transaction" : "Add expense"}
        text={
          isEditing
            ? "Change any detail and save. You'll go back to your transactions."
            : "Record money going out (debit) or coming in (credit)."
        }
        titleRef={titleRef}
      />

      <div className="add-page">
        <TransactionForm
          editingTransaction={editingTransaction}
          onAdd={onAdd}
          onUpdate={onUpdate}
          onCancel={onCancel}
        />
      </div>
    </>
  );
}

// =====================================================================
// DashboardPage.jsx — greeting, date filter, the three totals,
// analytics (bar / pie) and a preview of the most recent transactions.
// Everything here uses the date-filtered transactions from App.
// =====================================================================
import PageHeader from "../components/PageHeader";
import DateFilter from "../components/DateFilter";
import Dashboard from "../components/Dashboard";
import Analytics from "../components/Analytics";
import RecentTransactions from "../components/RecentTransactions";
import { getGreeting, formatLongDate } from "../utils/format";

export default function DashboardPage({ transactions, selectedDate, onDateChange, isReady, onNavigate, titleRef }) {
  return (
    <>
      <PageHeader
        eyebrow={formatLongDate()}
        title={getGreeting()}
        text="Here's where your money stands. Pick a date to zoom in on a single day."
        titleRef={titleRef}
      />

      <DateFilter selectedDate={selectedDate} onDateChange={onDateChange} />

      <Dashboard transactions={transactions} isReady={isReady} />

      <div className="dashboard-grid">
        <Analytics transactions={transactions} />
        <RecentTransactions transactions={transactions} onViewAll={() => onNavigate("transactions")} />
      </div>
    </>
  );
}

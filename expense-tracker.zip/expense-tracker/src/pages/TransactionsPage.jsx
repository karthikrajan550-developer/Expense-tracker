// =====================================================================
// TransactionsPage.jsx — the full list: date filter, search, type and
// category filters, sort, and Edit / Delete on every row.
// =====================================================================
import PageHeader from "../components/PageHeader";
import DateFilter from "../components/DateFilter";
import FilterBar from "../components/FilterBar";
import TransactionList from "../components/TransactionList";
import { ReceiptIcon } from "../components/Icons";

export default function TransactionsPage({
  allCount,
  dateCount,
  visibleTransactions,
  filters,
  onFiltersChange,
  selectedDate,
  onDateChange,
  highlightId,
  onEdit,
  onDelete,
  onNavigate,
  titleRef,
}) {
  return (
    <>
      <PageHeader
        eyebrow="History"
        title="Transactions"
        text="Search, filter, edit or delete anything you've recorded."
        titleRef={titleRef}
        action={
          <button type="button" className="btn btn--primary btn--icon" onClick={() => onNavigate("add")}>
            <svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true">
              <path d="M8 2v12M2 8h12" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
            </svg>
            Add expense
          </button>
        }
      />

      <DateFilter selectedDate={selectedDate} onDateChange={onDateChange} />

      <section className="panel" aria-labelledby="history-heading">
        <div className="panel__header">
          <h2 id="history-heading" className="heading-with-icon">
            <ReceiptIcon size={28} />
            All transactions
          </h2>
          <p className="panel__note">
            Showing {visibleTransactions.length} of {dateCount}
          </p>
        </div>

        <FilterBar filters={filters} onFiltersChange={onFiltersChange} />

        <TransactionList
          transactions={visibleTransactions}
          hasAnyTransactions={allCount > 0}
          isDateSelected={selectedDate !== null}
          onSelectDate={onDateChange}
          editingId={null}
          highlightId={highlightId}
          onEdit={onEdit}
          onDelete={onDelete}
        />
      </section>
    </>
  );
}

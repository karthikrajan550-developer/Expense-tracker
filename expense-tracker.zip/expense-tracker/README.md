# Expense Tracker (React + HTML + CSS)

An expense tracker where you record each expense with its **date**, plus any
**credit** (money in) and **debit** (money out). It shows your **balance** on a dashboard, gives you **analytics**
as a bar chart or a pie chart, and supports full **CRUD**.

No chart library is used. Both charts are built with plain HTML + CSS,
so every line can be explained in an interview.

---

## 1. How to run

You need Node.js 18 or newer.

```bash
npm install      # installs React and Vite
npm run dev      # open the URL it prints (usually http://localhost:5173)
npm run build    # production build in /dist
```

---

## 2. Features

| Feature | Where |
|---|---|
| Add credit or debit transaction | `TransactionForm.jsx` |
| Edit a transaction (form pre-fills) | `TransactionForm.jsx` + `App.jsx` |
| Delete with a "Yes, delete / Keep" confirm step | `TransactionItem.jsx` |
| **Filter by date**: All dates, Today, Yesterday, or any date from a date picker | `DateFilter.jsx` |
| Click a date heading in the list to show only that date | `TransactionList.jsx` |
| Selected date updates dashboard, charts **and** list together | `App.jsx` |
| Total Balance, total credit, total debit | `Dashboard.jsx` |
| Analytics: choose data (credit vs debit, spending by category, income by category) | `Analytics.jsx` |
| Analytics: choose chart type (Bar or Pie) | `Analytics.jsx` |
| Date defaults to today every time the app opens or the form resets | `TransactionForm.jsx` + `format.js` |
| Future dates blocked (`max` attribute + validation) | `TransactionForm.jsx` |
| List grouped by date ("Today", "Yesterday", "Sunday, 25 Oct 2026") with daily spend | `TransactionList.jsx` |
| Sort by date: Newest first / Oldest first | `FilterBar.jsx` + `calculations.js` |
| Search, filter by type, filter by category | `FilterBar.jsx` |
| Validation for credit and debit: title, amount and category are required, each with its own error message ("Please enter the amount.", "Please select a category."…) | `TransactionForm.jsx` |
| Loading screen on open / refresh: animated parallax scene (rider on a scooter through a landscape) + progress bar, then fades out | `LoadingScreen.jsx` + `useLoadingScreen.js` |
| Animations: title slides in, cards and panels appear one after another, bars grow, pie spins in, buttons lift and press, cards lift on hover | `index.css` (section 11) |
| Glossy Apple-style "glass" theme: frosted see-through panels, soft colourful background, gradient headline, glossy pill buttons, light sweep across cards on hover | `index.css` (section 12) |
| **Three pages switched by tabs**: Dashboard, Transactions, Add expense. The URL follows (`#/transactions`), so refresh and Back/Forward work | `useHashRoute.js` + `App.jsx` + `pages/` |
| Sticky glass **header** with page tabs; a pill slides to the active tab | `Header.jsx` |
| **Mobile bottom tab bar** with icons (phones and small tablets) | `TabBar.jsx` |
| Dashboard: greeting with today's date, totals, analytics and the 5 most recent transactions with "View all" | `DashboardPage.jsx` + `RecentTransactions.jsx` |
| Edit opens the form page pre-filled; saving returns to Transactions and flashes the row | `App.jsx` |
| Each page animates in; the browser tab title changes per page | `index.css` + `App.jsx` |
| **Footer**: copyright and back-to-top | `Footer.jsx` |
| Micro-interactions: button ripples, 3D card tilt with glare, panel spotlight, count-up amounts, sliding Bar/Pie switch, new-row flash, delete slide-out, shaking invalid fields | `useInteractiveEffects.js`, `AnimatedNumber.jsx`, `index.css` §13 |
| "Successfully added / updated" pop-up with an animated tick that fades away after 3 seconds | `Toast.jsx` |
| Data saved after refresh (localStorage) | `storage.js` + `App.jsx` |
| Responsive layout (desktop, tablet, mobile) | `index.css` |

---

## 3. Folder structure

```
expense-tracker/
├── index.html                    # The only HTML page. React renders into <div id="root">
├── public/
│   └── favicon.png               # Browser tab icon (linked in index.html)
├── package.json                  # Project name, scripts, dependencies
├── vite.config.js                # Tells Vite to use the React plugin
└── src/
    ├── main.jsx                  # Entry point: mounts <App /> into #root
    ├── App.jsx                   # Owns state + CRUD, picks which page to show
    ├── index.css                 # All styles
    │
    ├── assets/
    │   ├── logo.png              # App logo (header, loader)
    │   ├── wallet.png            # Icon on the Total Balance card
    │   ├── receive-amount.png    # Icon on the Total credit card
    │   └── spending.png          # Icon on the Total debit card
    ├── pages/                    # One file per tab; each arranges components
    │   ├── DashboardPage.jsx     # Greeting, date filter, totals, analytics, recent
    │   ├── TransactionsPage.jsx  # Date filter, search/filters, full list
    │   └── AddPage.jsx           # The form (add or edit), centred
    │
    ├── components/               # UI pieces (what the user sees)
    │   ├── Icons.jsx             # Illustrated SVG icons (calendar, clipboard, chart, receipt)
    │   ├── PageHeader.jsx        # Eyebrow + title + text block used by every page
    │   ├── RecentTransactions.jsx # Dashboard preview of the 5 newest
    │   ├── TabBar.jsx            # Bottom tab bar on phones
    │   ├── DateFilter.jsx        # Pick one date (or all dates)
    │   ├── Dashboard.jsx         # Balance / Credit / Debit cards
    │   ├── Analytics.jsx         # Data + chart-type pickers, shows a chart
    │   ├── charts/
    │   │   ├── BarChart.jsx      # Reusable bar chart (divs + CSS height)
    │   │   └── PieChart.jsx      # Reusable donut chart (CSS conic-gradient)
    │   ├── TransactionForm.jsx   # Add + Edit form
    │   ├── FilterBar.jsx         # Search, type chips, category + date-order dropdowns
    │   ├── TransactionList.jsx   # Groups transactions under date headings
    │   ├── TransactionItem.jsx   # One row with Edit / Delete
    │   ├── Toast.jsx             # "Successfully added" pop-up with animated tick
    │   ├── Header.jsx            # Sticky glass nav with page tabs
    │   ├── Footer.jsx            # Copyright + back-to-top
    │   ├── AnimatedNumber.jsx    # Counts smoothly to a new value
    │   └── loading/              # Loading screen, kept together in one folder
    │       ├── LoadingScreen.jsx # Layout, progress %, enter/exit
    │       ├── Scene.jsx         # Parallax landscape (layers, trees, mountains)
    │       ├── Rider.jsx         # Rider on a scooter, split into moving parts
    │       ├── sceneData.js      # All positions, sizes and colours as data
    │       └── loading.css       # All loading-screen motion
    │
    ├── hooks/
    │   ├── useLoadingScreen.js   # Custom hook: loading -> leaving -> done timers
    │   ├── useProgress.js        # Custom hook: eased 0 → 1 with requestAnimationFrame
    │   ├── useInteractiveEffects.js # Ripple, spotlight, card tilt (event delegation)
    │   ├── useHashRoute.js       # Tiny router: current page <-> URL hash
    │   └── useScrolled.js        # Has the page scrolled? (header style)
    │
    ├── data/
    │   └── constants.js          # Categories, colours, sample data
    │
    └── utils/                    # Plain JavaScript helpers (no React)
        ├── calculations.js       # Totals, chart data, filtering, date sort + grouping
        ├── format.js             # ₹ currency, dates, greeting, day headings
        ├── motion.js             # Easing curves + reduced-motion / pointer checks
        └── storage.js            # localStorage read / write
```

**Why this split?**
- `pages/` = **what's on each tab**. A page only arranges components and
  passes props; it holds no data of its own.
- `components/` = **how it looks**. Each file does one job.
- `utils/` = **logic**. Pure functions: same input, same output, easy to test.
- `data/` = **settings**. Add a category or change a colour in one place.

---

## 4. Architecture

### Component tree

```
main.jsx
└── App                        (state: transactions, editingTransaction, filters,
    │                           selectedDate, toast, highlightId + route from useHashRoute)
    ├── LoadingScreen          ← isLeaving   (only until useLoadingScreen() returns "done")
    │   └── Scene → Rider
    ├── Header                 ← route, onNavigate        (own hook: useScrolled)
    │
    ├── one page, chosen by `route`:
    │   ├── DashboardPage      ← transactions on the date, selectedDate, isReady, onNavigate
    │   │   ├── PageHeader, DateFilter
    │   │   ├── Dashboard → AnimatedNumber ×3
    │   │   ├── Analytics → BarChart | PieChart   (own state: dataView, chartType)
    │   │   └── RecentTransactions               ("View all" → onNavigate)
    │   ├── TransactionsPage   ← visible list, filters, selectedDate, onEdit, onDelete
    │   │   ├── PageHeader (+ "Add expense" action), DateFilter, FilterBar
    │   │   └── TransactionList → (date groups) → TransactionItem   (own state: isConfirming, isRemoving)
    │   └── AddPage            ← editingTransaction, onAdd, onUpdate, onCancel
    │       ├── PageHeader
    │       └── TransactionForm                   (own state: form, errors)
    │
    ├── Footer
    ├── TabBar                 ← route, onNavigate        (phones only, via CSS)
    └── Toast                  ← title, message, onClose  (only when toast !== null)
```

### Pages and routing
```
URL hash        route           page
#/dashboard  →  "dashboard"  →  DashboardPage   (default)
#/transactions → "transactions" → TransactionsPage
#/add        →  "add"        →  AddPage
```
- `useHashRoute(PAGE_IDS, DEFAULT_PAGE)` returns `[route, navigate]`, like `useState`.
- **React state is the source of truth**; the URL hash only mirrors it.
  On start the route is read from the hash, so refreshing keeps your page.
  A `hashchange` listener makes browser Back / Forward work.
- Writing the hash is in `try/catch`: in embedded previews that block URL
  changes, tabs still work (only Back/Forward don't).
- **Why not React Router?** For three pages a 40-line hook needs no extra
  package and shows how routing works. In a bigger app I'd use React Router:
  `<Routes><Route path="/" element={<DashboardPage />} /> …</Routes>` and
  `useNavigate()` instead of `navigate`. The pages would stay the same.
- **On every page switch** (an effect on `route` in App): the browser-tab
  title changes, the window scrolls to the top, the new page's `<h1>` gets
  focus for screen readers, and leaving the Add page cancels an unfinished edit.
- `<div className="page-view" key={route}>`: changing the `key` makes React
  mount a fresh element, so the page's entrance animation plays on every switch.

### Data flow rule: data goes down, events go up### Data flow rule: data goes down, events go up

```
             ┌───────────────── App (single source of truth) ─────────────────┐
             │  transactions   editingTransaction   filters                    │
             └───────┬──────────────────┬──────────────────────┬──────────────┘
      props (data) ↓ │                  │ ↑ callbacks          │
                     ▼                  ▼   (onAdd, onUpdate,   ▼
               Dashboard          TransactionForm  onDelete…) TransactionList
```

- **State lives in App** because several components need the same data
  (this is called *lifting state up*).
- **Children never change App's state directly.** They call a function
  that App passed to them as a prop (`onAdd`, `onDelete`, …).
- **Local UI state stays local.** Which chart is selected only matters to
  `Analytics`, and the "Yes, delete?" step only matters to one row, so those
  components keep their own `useState`.
- **Two levels of filtering.**
  ```
  transactions ──filterByDate(selectedDate)──► transactionsOnDate ──► Dashboard, Analytics
                                                       │
                                     filterTransactions(filters)
                                                       ▼
                                              visibleTransactions ──► TransactionList
  ```
  The date filter changes the Dashboard (totals, charts, recent) and the
  Transactions list, and it's shared, so it stays set when you switch tabs.
  Search, type, category and sort only change the list.
- **Derived data is calculated, not stored.** Balance, totals, chart data and
  the filtered list are computed from `transactions` on every render. This
  avoids two copies of the same data getting out of sync.

### State summary

| State | Lives in | Why there |
|---|---|---|
| `transactions` | App | Needed by Dashboard, Analytics, List |
| `selectedDate` | App | Set by DateFilter **and** by date headings in the list; used by Dashboard, Analytics and List |
| `route` | App (`useHashRoute`) | Header, TabBar and App all need the current page |
| `editingTransaction` | App | Set on the Transactions page (Edit), used on the Add page (form) |
| `filters` (`type`, `category`, `search`, `sortOrder`) | App | FilterBar changes it, App uses it to filter + sort the list |
| `form`, `errors` | TransactionForm | Only the form needs them |
| `dataView`, `chartType` | Analytics | Only the analytics panel needs them |
| `isConfirming` | TransactionItem | Only that one row needs it |
| `toast` | App | Set by add/update in App; `null` hides the pop-up |
| `highlightId` | App | The row that was just added/updated (flashes); cleared with the toast |

### Transaction data shape

```js
{
  id: "1730012345678",   // Date.now() as a string, unique
  title: "October salary",
  amount: 52000,         // always a number
  type: "credit",        // "credit" (money in) or "debit" (money out)
  category: "Salary",
  date: "2026-10-01"     // YYYY-MM-DD, same format as <input type="date">
}
```

---

## 5. File by file: what each one does

### `index.html`
The only HTML page. It loads the font, has an empty `<div id="root">`, and
loads `src/main.jsx`. React fills that div with the whole app.

### `public/favicon.png`
The icon shown in the browser tab. Files in `public/` are served as they are
from the site root, so `index.html` links it with
`<link rel="icon" type="image/png" href="/favicon.png" />`.

### `src/assets/logo.png`
The logo in the header. `App.jsx` imports it with
`import logo from "./assets/logo.png"`. Vite turns that import into the
correct image URL and adds a cache-busting hash in production builds.

**`public/` vs `src/assets/`:** files in `public/` are copied as-is and used by
plain path (good for the favicon, which `index.html` needs). Files in
`src/assets/` are imported in code, so Vite processes them and errors if the
file is missing (good for images used inside components).

### `src/components/Icons.jsx`
Small illustrated icons drawn with inline SVG, in the same colourful,
thick-outline style as the logo. Each icon is a React component with a
`size` prop: `<ChartIcon size={28} />`.
- `IconBase` wraps every icon and applies the dark outline to all shapes once,
  so each icon only lists its shapes and fill colours.
- All colours live in one object `C`, so the whole set can be recoloured in one place.
- Icons have `aria-hidden="true"` because the text beside them already says
  what they mean, so screen readers don't read them twice.

| Icon | Used in |
|---|---|
| `CalendarIcon` | Date filter bar |
| `AddNoteIcon` | Add / Edit transaction form |
| `ChartIcon` | Analytics heading |
| `ReceiptIcon` | Transactions heading and empty state |

### `src/main.jsx`
Entry point. `ReactDOM.createRoot(...).render(<App />)` hands control of
`#root` to React. `StrictMode` shows extra warnings during development.

### `src/App.jsx`
The brain of the app.
1. Creates the shared state: `transactions`, `editingTransaction`, `filters`,
   `selectedDate` (`null` means all dates), `toast` and `highlightId`.
   The current page comes from `useHashRoute` as `[route, navigate]`.
2. `useState(loadTransactions)` — passing the function (not calling it) means
   it runs only on the first render.
3. `useEffect(..., [transactions])` saves to localStorage whenever the list changes.
4. `useEffect(..., [route])` runs on every page switch: tab title, scroll to
   top, focus the page title, cancel an unfinished edit when leaving "Add".
5. Defines the CRUD functions (see section 6). Edit and Save also navigate:
   Edit → Add page, Save/Cancel → Transactions page.
6. Filters in two steps: `transactionsOnDate = filterByDate(transactions, selectedDate)`
   goes to the Dashboard page, then `visibleTransactions = filterTransactions(transactionsOnDate, filters)`
   goes to the Transactions page.
7. `renderPage()` returns the page for the current `route`, wrapped in
   `<div className="page-view" key={route}>` so each switch animates in.

### `src/pages/` (one file per tab)
Pages only **arrange** components and pass props down; all data lives in App.
- **`DashboardPage.jsx`**: `PageHeader` (greeting + today's date), `DateFilter`,
  `Dashboard` (totals), and a two-column grid with `Analytics` and `RecentTransactions`.
- **`TransactionsPage.jsx`**: `PageHeader` with an "Add expense" button,
  `DateFilter`, then the list panel with `FilterBar` and `TransactionList`.
- **`AddPage.jsx`**: `PageHeader` ("Add expense", or "Edit transaction" when
  editing) and `TransactionForm`, centred at 560px wide.

### `src/components/PageHeader.jsx`
The same title block at the top of every page (eyebrow, `<h1>`, one line of
text, optional action button), so all pages line up identically. The `<h1>`
has `tabIndex={-1}` so App can move focus to it after a page switch.

### `src/components/RecentTransactions.jsx`
The 5 newest transactions (for the selected date), read-only, with a coloured
category dot, the day ("Today", "Yesterday"…) and the amount. "View all" opens
the Transactions page.

### `src/components/TabBar.jsx`
Bottom tab bar shown only on screens under 760px (CSS), where the header has
no room for tabs. Icons + labels; a pill slides to the active tab using the
`--index` CSS variable. The page gets extra bottom padding so the bar never
covers the footer.

### `src/components/DateFilter.jsx`
A bar above the dashboard that shows what is being viewed ("All dates" or
"Thursday, 15 Oct 2026") with quick buttons (All dates, Today, Yesterday) and
a date picker. It has no state of its own: every click calls
`onDateChange(date)` and App updates `selectedDate`. Clearing the picker gives
an empty string, which is turned into `null` (all dates). `max={today}` blocks
future dates.

### `src/components/Dashboard.jsx`
Receives only the transactions for the selected date, so the cards show that
day's totals. Calls `getTotals(transactions)` and shows three cards: Total Balance (credit − debit),
Total credit, Total debit. If balance is negative, the number turns red and
the note text changes (conditional class + conditional text).

### `src/components/Analytics.jsx`
Has two local states: `dataView` (what data) and `chartType` (bar or pie).
Calls `getChartData(transactions, dataView)` to get `[{label, value, color}]`.
Then renders one of three things: an empty message, `<BarChart>`, or `<PieChart>`.
Both charts accept the **same data shape**, so switching is just changing
which component is rendered. Because App passes it the date-filtered list,
the charts automatically show only the selected date.

### `src/components/charts/BarChart.jsx`
Finds the biggest value. Each bar's height is `value / max * 100` percent
inside a fixed-height track. The CSS `align-items: flex-end` makes bars grow
upward from the bottom.

### `src/components/charts/PieChart.jsx`
Uses CSS `conic-gradient`, which paints colours around a circle.
It loops through the data keeping a running `start` percentage, building
strings like `"#7a5ac8 0% 69%"`, `"#e08e2b 69% 84%"` and joins them.
A white circle in the centre makes it a donut and shows the total.

### `src/components/TransactionForm.jsx`
One form for both **Add** and **Edit**.
- *Controlled inputs*: each input's `value` comes from `form` state, and
  `onChange` updates it.
- One `handleChange` for all inputs using `[name]: value`.
- **Category starts empty** ("Select a category"), so the user must choose one.
  Switching Credit/Debit clears it again, because "Food" doesn't exist under Credit.
- **Default date = today.** `getEmptyForm()` calls `getToday()` every time it
  runs: when the app opens, after each add, and when editing is cancelled.
  So the date is always the current date, never a stale one.
- `max={getToday()}` stops the date picker going into the future, and
  `validate()` also rejects a typed future date.
- `useEffect` watches `editingTransaction`: fills inputs when editing starts,
  resets them when editing ends.
- **Validation** (`validate()` returns an object of messages; empty = valid):

  | Field | Problem | Message |
  |---|---|---|
  | Title | empty | Please enter a title. |
  | Amount | empty | Please enter the amount. |
  | Amount | 0 or less | Amount must be greater than 0. |
  | Category | not chosen | Please select a category. |
  | Date | empty | Please select a date. |
  | Date | in the future | Date can't be in the future. |

  The same rules apply to both Credit and Debit, and to Add and Edit.
- Each error shows under its own field, the field gets a red border
  (`aria-invalid`), and the message is linked with `aria-describedby` so
  screen readers read it.
- On a failed submit, the cursor moves to the first invalid field (`FIELD_ORDER`).
- When the user starts fixing a field, only that field's error disappears.
- `handleSubmit`: `preventDefault()` → `validate()` → stop if errors →
  call `onAdd` or `onUpdate` (App then shows the success pop-up).

### `src/components/Toast.jsx`
The pop-up shown after a successful add or update.
- **Timer:** a `useEffect` starts `setTimeout(onClose, 3000)`. Its cleanup
  function (`return () => clearTimeout(timer)`) cancels the timer if the
  toast is replaced or removed early, so there are no stray timers.
- **Fade in and out are pure CSS:** `toast-in` runs at the start, and
  `toast-out` starts at 2.6s, so the box has faded out by the time React
  removes it at 3s.
- **Animated tick** (SVG, styled like the reference GIF): the circle pops in
  (`tick-pop`), then the check mark draws itself. The trick is
  `stroke-dasharray` + `stroke-dashoffset`: the line starts fully offset
  (invisible) and animates to `0` (fully drawn).
- `role="status"` + `aria-live="polite"` makes screen readers announce it.
- With "reduce motion" turned on in the OS, it skips the sliding and drawing
  and just fades out.

**Why SVG + CSS instead of the GIF?** The GIF loops forever and doesn't
reliably restart when shown again. The SVG version plays once every time,
stays sharp at any size, and is about 1 KB instead of 200 KB.

### `src/components/FilterBar.jsx`
Shows a search box, All/Credit/Debit chips, a category dropdown and a
date-order dropdown (Newest first / Oldest first).
It does **not** keep its own state; it builds a new filters object and sends
it up with `onFiltersChange`. Changing type resets category to "all",
because "Salary" doesn't exist under Debit.

### `src/components/TransactionList.jsx`
If the list is empty, shows a message (different text if there's no data at
all vs. filters hiding everything). Otherwise it calls `groupByDate()` on the
already-sorted list and renders one section per day: a clickable heading
(clicking calls `onSelectDate(group.date)` to filter the page to that day)
("Today", "Yesterday", or "Sunday, 25 Oct 2026"), that day's total spent,
then a `<TransactionItem>` per transaction with a unique `key`.

### `src/components/TransactionItem.jsx`
Displays one transaction (the date is shown once in the group heading, not
on every row). Credit amounts get `+` and green, debit get `−` and red.
Category colour is passed as a CSS variable (`--category-color`) for the left border.
Delete uses a small local state `isConfirming` to show "Yes, delete / Keep"
instead of a browser popup.

### `src/hooks/useLoadingScreen.js`
A **custom hook** (a function starting with `use` that uses other hooks).
It returns the loading stage and moves it forward with two timers:

```
"loading" ──2.2s──► "leaving" ──0.65s──► "done"
scene playing       rider rides off,      screen removed from the page
                    screen fades out
```
The `useEffect` has `[]` as dependencies, so it runs once when the app opens,
which is every time the page is refreshed. Its cleanup clears both timers.
Keeping this in a hook means App only writes `const loadingStage = useLoadingScreen();`.

### The loading screen (`src/components/loading/`)
Everything for the loader lives in one folder: components, data and CSS.

**Timeline**
```
0.0s    scene glides in (fade + rise + slight scale), then title, text, bar (stagger)
0→2.2s  progress counts 0% → 100% (eased); the landscape scrolls; rider rides
2.2s    stage "leaving": the rider ACCELERATES off to the right,
        text sinks away, then the screen fades (0.3s later)
        the app's entrance animations start underneath
2.85s   stage "done": loader removed from the page
```

**`LoadingScreen.jsx`**: the layout (scene, title, text, progress bar) and the
`isLeaving` class. Uses `useProgress(LOADING_TIME)` for the percentage. The bar
fills with `transform: scaleX(progress)` rather than `width`, because transforms
run on the GPU and don't trigger layout. It has `role="progressbar"` with
`aria-valuenow` so screen readers can hear the progress.

**`Scene.jsx`**: the landscape, layered back to front:

| Layer | Speed (one loop) | Why |
|---|---|---|
| Sky + sun | still | "infinitely" far away; the sun's glow gently pulses |
| Clouds | 90s | very far |
| Far range | 48s | pale and hazy (atmospheric perspective) |
| Mountains | 26s | lit left faces + snow caps |
| Back hill + pines | 13s | |
| Front hill + trees | 6.5s | |
| Road + bushes | 1.7s | ground speed: what the rider is actually driving on |

Each layer is ~half the speed of the one in front, which is how real depth
looks. Every layer is drawn once in `<defs>` and placed twice with `<use>`
(x = 0 and x = 800). CSS slides it left by exactly 800, so the loop is seamless.
The slide distance comes from `--scene-width`, set from `SCENE_WIDTH` in JS:
one number, used by both.
Birds glide across separately and flap their wings.

**`Rider.jsx`**: drawn relative to the rear wheel, and split into parts that
move differently, because that is what makes motion believable:

| Part | Motion |
|---|---|
| Wheels | spin, but stay planted on the road |
| Scooter body | bobs on its "suspension" |
| Person | bobs too, 70 ms later and with a tiny tilt (**secondary motion**) |
| Scarf | flutters in the wind |
| Exhaust | three puffs, staggered, drift back, grow and fade |
| Speed lines | streak backwards and fade |
| Shadow | squashes slightly when the body lifts |

Details like gloss highlights on the scooter and helmet, a headlight glow
and a ₹ delivery box are all plain SVG shapes.

**`sceneData.js`**: every position, size and colour as data (arrays of
peaks, pines, trees, bushes, clouds). The components just `.map()` over them.
Mountains are generated from `{ x, y, w }`: the snow cap and lit face are
calculated from the peak, so moving a mountain is one number change.

**`loading.css`**: all timing. Rules followed:
- Only `transform` and `opacity` are animated (smooth, GPU-friendly).
- Named easing curves: `--ease-out-expo` for entrances (quick then soft),
  `--ease-in-strong` for the ride-off (slow then fast, so it accelerates).
- `transform-box: fill-box` makes wheels, puffs and the scarf rotate or
  scale around their own centre.
- Reduced motion: a still landscape, no puffs or speed lines; only the
  progress bar and the fade remain.

**`hooks/useProgress.js`**: returns a number from 0 to 1 over a duration,
updated with `requestAnimationFrame` (in step with the screen refresh, and
paused in background tabs). Eased with "ease-out quad" so it starts a bit
faster and slows gently, but keeps moving all the way to 100%.

**Note:** the data loads from localStorage instantly, so this screen is mainly
for the look and feel. With a real backend you would show it while the
`fetch` request is in progress instead of using a fixed timer.

### Animations (`index.css`, section 11)
- **Entrance:** App adds the `is-ready` class when the loader starts fading.
  Every entrance rule starts with `.is-ready`, so nothing animates while it is
  hidden behind the loader. Cards use `animation-delay` with `nth-child` so they
  appear one after another (a "stagger").
- **`fill-mode: backwards`:** the element is hidden during its delay, and after
  the animation it returns to normal CSS. With `forwards` or `both`, the final
  keyframe would stay applied and block the hover `transform`.
- **Charts:** bars grow from the bottom (`scaleY` with `transform-origin: bottom`),
  the pie scales and rotates in. They replay when you switch views because
  the chart elements are new.
- **New rows** fade in as soon as they are added.
- **Hover / press:** buttons and chips lift 2px on hover and shrink to 96% when
  pressed; dashboard cards lift and their icon tilts; rows nudge right; the logo wiggles.
- **Reduced motion:** if the user has turned on "reduce motion" in their OS,
  entrance animations and hover movement are switched off.

### Glossy theme (`index.css`, section 12)
An Apple-style "glass" look built only with CSS:
- **Background:** several soft `radial-gradient` colour spots behind the page
  (`--page-gradient`), fixed in place while you scroll.
- **Frosted glass panels:** a see-through white gradient plus
  `backdrop-filter: blur(20px) saturate(170%)`, which blurs whatever is behind
  the panel, a bright 1px white border, and a soft shadow with an
  `inset` top highlight that looks like light catching the edge.
- **Gradient headline:** `background-clip: text` with `color: transparent`
  shows the gradient through the letters.
- **Glossy buttons:** pill shape, a top-to-bottom gradient and an inset white
  highlight on the primary button and active chips.
- **Light sweep:** a slanted white band (`::after`) slides across dashboard
  cards and the main button on hover, like light reflecting off glass.
- **Glossy charts:** a soft highlight on the bars and depth shadows on the pie.
- All the glass values are CSS variables in `:root` (`--glass-bg`, `--glass-blur`…),
  so the look can be tuned in one place.

### Page structure and alignment
```
<Header>          sticky, full width; content inside .container
<main.container>  <div.page-view key={route}> PageHeader → page blocks… </div>
<Footer>          full width; content inside .container
<TabBar>          phones only, floating at the bottom
```
- **One container** (`max-width: var(--container)` + `--gutter` padding) is used
  by the header, the pages and the footer, so every left and right edge lines up.
- **One rhythm:** `.page-view` is a flex column with `gap: var(--section-gap)`,
  so every block on every page is the same distance apart.
- **One title block:** every page starts with `PageHeader`, so titles sit in
  exactly the same place when you switch tabs.
- **One control height:** `--control-h` (40px) for selects, date inputs, the
  Bar/Pie switch and buttons, so controls in a row line up.
- **Skip link:** keyboard users can press Tab once and jump past the header.

### `src/components/Header.jsx`
- **Page tabs:** Dashboard, Transactions, Add expense. Links keep a real `href`
  (`#/transactions`, so they can be opened in a new tab), but a normal click
  calls `onNavigate(id)` and the app switches page without reloading.
- **Sliding pill:** the active tab's `offsetLeft` and `offsetWidth` are measured
  in `useLayoutEffect` (runs before paint, so the pill never flickers in the
  wrong place) and the pill moves there with a springy CSS transition.
  It re-measures on window resize. `aria-current="page"` marks the active tab.
- **Scrolled style:** `useScrolled` switches to stronger glass + shadow after 8px.
- Below 760px the tabs move to the bottom `TabBar`.

### `src/components/Footer.jsx`
One slim row: the copyright with the year (`new Date().getFullYear()`, so it
never goes out of date) and a note on the left, and a back-to-top button on
the right. On phones the button sits above the small print.

### `src/components/AnimatedNumber.jsx`
Counts from the current value to the new one with `requestAnimationFrame`
and an ease-out curve. Used for the three dashboard amounts, so adding,
deleting or filtering makes the totals roll to their new values.
- `useRef` remembers the number on screen without causing re-renders, so a
  new change starts from wherever the last animation got to.
- `isActive={isReady}` holds it at 0 behind the loader, so the first count-up
  happens when the user can actually see it.
- Whole rupees while moving, the exact amount at the end.

### `src/hooks/useInteractiveEffects.js`
Pointer effects for the whole app using **event delegation**: three listeners
on `document` instead of one per button or card. New elements get the
effects automatically, with nothing to clean up per element.
- **Ripple:** on `pointerdown` over a button/chip, a `<span class="ripple">`
  is placed at the pointer and removes itself on `animationend`.
- **Spotlight:** on `pointermove` over a `.panel`, the pointer position is
  written to `--mx` / `--my`; CSS draws a soft radial light there.
- **Tilt + glare:** over a `.stat` card, the position also becomes `--rx` / `--ry`
  (max 8°); CSS rotates the card in 3D and a glare follows the cursor.
- Pointer moves are throttled with `requestAnimationFrame` (max once per frame).
- Hover effects only run with a mouse (not touch), and nothing runs when the
  user prefers reduced motion.

### Micro-interactions (`index.css`, section 13)
| Element | Interaction |
|---|---|
| Buttons, chips, toggles | ripple from the press point; lift on hover; press down on click |
| Header "+" | rotates 90° on hover |
| Dashboard cards | 3D tilt toward the cursor + glare; icon pops |
| Panels | soft spotlight under the cursor; heading icon wiggles |
| Bar/Pie switch | white pill slides with a slight spring (`--index` from React) |
| Bars / pie legend | value label pops, bar brightens; legend rows nudge |
| New / updated row | soft blue glow that fades (`row-flash`) |
| Deleted row | slides right, fades, then collapses its space (`row-out`) |
| Invalid field | shakes once; the error message slides in |
| Back to top | arrow nudges up |

**Delete animation flow:** "Yes, delete" → `isRemoving = true` → row plays
`row-out` → `onAnimationEnd` (only for `row-out`) → `onDelete(id)` → App removes it.
A fallback timer deletes anyway after 800ms, and with reduced motion it deletes
immediately, so a row can never get stuck.

### `src/data/constants.js`
Categories per type, a colour per category, the localStorage key, and
sample data for the first visit. Sample dates use `getDateDaysAgo(n)`, so
the demo always has entries for "Today" and "Yesterday".

### `src/utils/calculations.js`
Pure functions:
- `sumAmounts(list)` → total using `reduce`
- `getTotals(list)` → `{ credit, debit, balance }`
- `getCategoryTotals(list, type)` → chart data per category, biggest first
- `getChartData(list, view)` → picks the right data for the analytics view
- `filterByDate(list, selectedDate)` → only that date's transactions, or all if `null`
- `sortByDate(list, order)` → copies the array (`[...list]`) and sorts by date;
  same-date items are ordered by `id` (time added). `"newest"` or `"oldest"`.
- `filterTransactions(list, filters)` → type + category + search, then `sortByDate`
- `groupByDate(sortedList)` → `[{ date, items, spent }]`. Because the list is
  already sorted, one pass is enough: same date as the last group → add to it,
  otherwise start a new group.

### `src/utils/format.js`
`formatCurrency` (₹52,000), `formatCompactCurrency` (₹52K, ₹1.5L for chart
labels), `formatDate` (1 Oct 2026), `getToday` (current date as `YYYY-MM-DD`),
`getDateDaysAgo(n)`, and `formatDayHeading` ("Today" / "Yesterday" / full date).

**Why not just `new Date().toISOString().slice(0, 10)`?** `toISOString` uses UTC.
India is UTC+5:30, so between midnight and 5:30 AM it would give *yesterday's*
date. `toInputDate` adjusts for the time zone first.

### `src/utils/storage.js`
`loadTransactions` reads + `JSON.parse`, falling back to sample data.
`saveTransactions` does `JSON.stringify` + write. Both use `try/catch`
so the app keeps working if storage is blocked.

### `src/index.css`
Organised into numbered sections: tokens (CSS variables), base, layout
(CSS Grid), dashboard, form, buttons, analytics, filter bar, list, and
responsive media queries (900px → one column, 640px → mobile tweaks).

---

## 6. End-to-end code flow

### App starts
```
index.html loads main.jsx
 → main.jsx renders <App />
 → App: useState(loadTransactions) → storage.js reads localStorage
       (first visit: sample data from constants.js)
 → useLoadingScreen() returns "loading" → LoadingScreen covers the page
 → useHashRoute reads the URL hash: "#/transactions" → that page, nothing → Dashboard
 → selectedDate = null, so filterByDate() returns everything
 → App computes visibleTransactions via filterTransactions()
 → renderPage() → DashboardPage (or the page from the URL)
     → DateFilter shows "All dates"
     → Dashboard → getTotals() → the three totals
     → Analytics → getChartData() → BarChart
     → RecentTransactions → the 5 newest
 → after 2.2s: stage "leaving" → .app gets "is-ready" → loader fades out,
   the page's blocks and cards animate in one after another
 → after 2.85s: stage "done" → LoadingScreen is removed
```

### SWITCH PAGE: user clicks the "Transactions" tab
```
Header link onClick      → preventDefault() → onNavigate("transactions")
useHashRoute.navigate    → setRoute("transactions") + location.hash = "/transactions"
React re-renders App     → Header pill slides to "Transactions"; TabBar pill too
                         → renderPage() returns <TransactionsPage>
                         → new key on .page-view → its blocks animate in
useEffect([route])       → document.title = "Transactions · Expense Tracker"
                         → scroll to top, focus the page <h1>
Browser Back             → "hashchange" → setRoute("dashboard") → Dashboard again
```

### CREATE: user adds a credit of ₹2,000 (Add expense page)
```
User clicks "Credit"         → handleChange: type = "credit", category = "" (must choose)
User types title/amount      → handleChange updates form state on each key
User picks "Salary"          → handleChange: category = "Salary"
Date field already shows today (user can change it to a past date)
User clicks "Add credit"     → handleSubmit
   → preventDefault()        (no page reload)
   → validate()              missing title / amount / category, amount ≤ 0, future date?
                             → YES: show each message, shake, focus first bad field, STOP
                             → NO:  continue
   → onAdd(transaction)      (prop from App)
App.addTransaction           → setTransactions([newTransaction, ...prev])
                             → setHighlightId(newTransaction.id)
                             → showToast("Successfully added", "Credit of ₹2,000 · Salary")
We stay on the Add page      → so several entries can be added one after another
handleSubmit                 → setForm(getEmptyForm()) → date resets to today
useEffect([transactions])    → saveTransactions() writes to localStorage
<Toast> appears              → slides in, circle pops, tick draws; gone after 3s
Dashboard / Transactions     → show the new totals and row next time you open them
```

### READ: user filters to Debit + Food
```
User clicks "Debit" chip     → FilterBar.updateFilter("type", "debit")
                             → onFiltersChange({ ...filters, type: "debit", category: "all" })
App.setFilters               → re-render
                             → filterTransactions() returns only debit items
User picks "Food"            → same flow, category = "Food"
List shows only Food debits. Dashboard + Analytics are NOT affected by these
list filters (they follow only the date filter).
User picks "Oldest first"    → filters.sortOrder = "oldest"
                             → sortByDate() reverses the order → groups re-render oldest → newest
```

### UPDATE: user edits a transaction
```
Transactions page: "Edit"    → onEdit(transaction) → App.startEditing
                             → setEditingTransaction(transaction) + navigate("add")
AddPage                      → title "Edit transaction"
TransactionForm useEffect    → sees editingTransaction → fills the inputs; button "Save changes"
User changes amount, saves   → handleSubmit → validate → onUpdate(transaction)
App.updateTransaction        → prev.map(): replace item with same id
                             → setEditingTransaction(null), setHighlightId(id)
                             → showToast("Successfully updated", …) + navigate("transactions")
Transactions page            → the changed row flashes blue; if the date changed,
                               it's already in its new date group (re-sorted every render)
Cancel                       → setEditingTransaction(null) + navigate("transactions")
Switching tab while editing  → useEffect([route]) clears editingTransaction,
                               so "Add expense" later shows an empty form
```

### DELETE: user deletes a transaction
```
User clicks "Delete"         → TransactionItem: setIsConfirming(true)
                             → row now shows "Yes, delete" and "Keep"
User clicks "Yes, delete"    → row plays its slide-out animation
                             → onAnimationEnd → onDelete(id) → App.deleteTransaction
                             → prev.filter(item => item.id !== id)
Totals, charts, list update; useEffect saves to localStorage.
```

### DATE FILTER: user picks 15 Oct 2026
```
User picks a date in the picker  → DateFilter onChange → onDateChange("2026-10-15")
   (or clicks "Today"/"Yesterday", or clicks a date heading in the list)
App.selectDate                   → setSelectedDate("2026-10-15") + scroll to top
   (the date is shared: it stays selected when you switch between Dashboard and Transactions)
React re-renders App             → filterByDate() keeps only 15 Oct transactions
   → DateFilter   shows "Thursday, 15 Oct 2026" and highlights the picker box
   → Dashboard    Total Balance / credit / debit for 15 Oct only
   → Analytics    bar or pie chart for 15 Oct only
   → List         only 15 Oct rows (search/type/category still work on top)
User clicks "All dates"          → onDateChange(null) → everything is shown again
```
A day with no transactions shows ₹0 on the dashboard, a "No data" message in
the chart, and "No transactions on this date" in the list.

### ANALYTICS: user switches chart
```
User selects "Spending by category" → Analytics.setDataView("spending")
   → getChartData() → getCategoryTotals(transactions, "debit")
   → [{ label: "Bills", value: 16850, color }, ...]
User clicks "Pie"                   → Analytics.setChartType("pie")
   → renders <PieChart data={chartData} /> instead of <BarChart />
Same data, different component. Nothing else in the app re-renders differently.
```

---

## 7. React concepts used (and where)

| Concept | Example |
|---|---|
| `useState` | `transactions` in App, `form` in TransactionForm |
| Lazy initial state | `useState(loadTransactions)` in App |
| `useEffect` with dependency | Save on `[transactions]`, fill form on `[editingTransaction]` |
| Props + callbacks | `onAdd`, `onUpdate`, `onDelete`, `onFiltersChange` |
| Lifting state up | `transactions` and `filters` live in App |
| Local component state | `chartType` in Analytics, `isConfirming` in TransactionItem |
| Controlled components | Every form input |
| Conditional rendering | Empty states, Bar vs Pie, Edit mode, delete confirm |
| Lists and `key` | `transactions.map(...)` with `key={transaction.id}` |
| `key` to restart a component | `<Toast key={toast.id} />` replays the animation for each new toast |
| `useEffect` cleanup | `clearTimeout` in Toast |
| `useCallback` | `hideToast` in App keeps the same function so Toast's timer isn't reset on re-renders |
| Form validation | `validate()` + `errors` state in TransactionForm |
| Custom hook | `useLoadingScreen()` returns the loading stage |
| Client-side routing | `useHashRoute()` returns `[route, navigate]`; App renders one page |
| `key` to remount a page | `<div className="page-view" key={route}>` replays the page animation |
| Focus management | page `<h1>` focused after each switch (`tabIndex={-1}` + `ref`) |
| Derived state | Balance, totals, chart data, filtered + sorted + grouped list |
| Immutable updates | Spread `...`, `map`, `filter` (never `push` or `splice`) |
| Reusable components | BarChart and PieChart share one data shape |

## 8. CSS concepts used

CSS variables, Flexbox, CSS Grid, `position: sticky` and `position: fixed`
(toast, loader), `@keyframes` animations, `animation-delay` stagger with
`:nth-child`, `animation-fill-mode`, `::before` pseudo-element spinner,
hover / `:active` transforms, `backdrop-filter` glassmorphism,
`background-clip: text`, `radial-gradient` backgrounds, SVG `clipPath` and
`<use>`, parallax looping animation, `transform-box: fill-box`, SVG `stroke-dashoffset` line drawing, `conic-gradient`,
`:has()` and `:focus-visible` for keyboard focus, `clamp()` for fluid font
size, media queries, and `prefers-reduced-motion`.

---

## 9. Common interview questions about this project

**How do you make sure the default date is always today?**
The form's initial state comes from a function, `getEmptyForm()`, which calls
`getToday()` each time. It isn't a fixed value saved once, so every app open
and every form reset gets the current date.

**How is the list kept in date order?**
`sortByDate()` runs on every render, so new or edited transactions land in the
right place automatically. It sorts a copy (`[...list]`) because `.sort()`
changes the original array, and React state must never be mutated.

**Why is the balance not stored in state?**
It can always be calculated from transactions. Storing it would create a
second copy that could get out of sync.

**Why do charts not use a library?**
To keep it lightweight and show I understand the logic. In a bigger app
I'd use Recharts or Chart.js for tooltips, axes and animations.

**What is a custom hook and why did you make one?**
It's a function starting with `use` that uses other hooks. `useLoadingScreen`
holds the loading-screen state and timers, so App stays focused on the data
and the logic can be reused or tested on its own.

**Is the loading screen really waiting for something?**
Not here, because localStorage is instant. It's a fixed 2.2s for the
experience. With an API, I'd set the stage to "leaving" when the `fetch`
finishes instead of using a timer.

**What was a tricky bug you fixed?**
The delete animation didn't play and the row was never removed. The entrance
rule `.is-ready .transaction` had higher CSS specificity than
`.transaction--removing`, so the exit animation was overridden, and the
`animationend` event the delete waited for never fired. I raised the
specificity (`.app .transaction.transaction--removing`) and added a fallback
timer so the UI can't get stuck if an event is missed.

**How do the pages work without a page reload?**
It's a single-page app. `useHashRoute` keeps the current page in React state
and mirrors it in the URL hash (`#/transactions`). Changing the hash never
reloads the page, so App just renders a different page component. Reading the
hash on start keeps your page after a refresh, and a `hashchange` listener
makes Back / Forward work.

**Why a hash router instead of React Router?**
For three pages a 40-line hook is enough, needs no package, and works when
the file is opened directly or embedded. In a larger app I'd use React Router
(`<Routes>`, `<Route>`, `useNavigate`); the page components wouldn't change.

**Where does state live when you switch pages?**
In App, above all pages. Pages unmount when you leave them, so anything kept
inside a page would reset. Transactions, filters and the selected date live
in App, so they survive tab switches. The chart type lives in `Analytics`,
so it resets, which is fine for a view setting.

**What is event delegation and why use it?**
One listener on a parent (here `document`) handles events for many children
using `event.target.closest(selector)`. It's cheaper than a listener per
button, and elements added later work automatically.

**Why `useLayoutEffect` in the header?**
It runs after React updates the DOM but before the browser paints, so I can
measure the active tab and place the pill without a one-frame flicker.

**Why move focus to the page title after switching tabs?**
In a single-page app the browser doesn't announce a "new page". Focusing the
`<h1>` (made focusable with `tabIndex={-1}`) tells screen-reader users where
they are, and keyboard users continue from the top of the new page.

**Why does AnimatedNumber use `useRef`?**
It needs to remember the number currently on screen between animations.
A ref keeps that value without causing extra re-renders.

**What makes the loading animation feel realistic?**
Three animation principles: **parallax** (each layer about half the speed of
the one in front), **secondary motion** (the rider bobs a moment after the
scooter, the scarf flutters), and **anticipation/acceleration** on exit (the
rider speeds up with an ease-in curve instead of moving at a constant speed).
The wheels stay on the road while only the body bobs, like real suspension.

**Why animate `transform` instead of `left` or `width`?**
Changing `left`/`width` makes the browser recalculate layout every frame.
`transform` and `opacity` can be handled by the GPU, so the animation stays
smooth at 60fps even on phones.

**Why `requestAnimationFrame` for the percentage?**
It runs once per screen refresh, so the number updates exactly as often as
the screen can show it, and the browser pauses it in background tabs.
`setInterval` would run at a fixed rate whether or not the screen updates.

**How does the loading animation loop without a jump?**
Each layer is drawn twice, side by side, and slides left by exactly one copy's
width. At the end of the loop the second copy sits where the first began, so
restarting is invisible. Each layer has a different speed, which creates parallax.

**How is the glass effect made?**
`backdrop-filter: blur()` blurs the content behind a semi-transparent panel.
Combined with a thin white border, an inset highlight and a soft shadow,
it looks like frosted glass, as on Apple's website.

**How does the success pop-up disappear on its own?**
When it appears, a `useEffect` starts a 3-second `setTimeout` that calls
`onClose`, which sets `toast` to `null`. CSS fades it out just before that.
The effect's cleanup clears the timer if the toast is replaced early.

**Why do you need `useCallback` for `hideToast`?**
Without it, App creates a new function on every render. Because `onClose` is
in the Toast effect's dependency array, a new function would restart the
timer each time App re-renders (for example while typing in the search box),
and the toast might never hide.

**Why does the toast have `key={toast.id}`?**
If you add two transactions quickly, the second toast gets a new `id`. A new
`key` makes React mount a fresh Toast, so the animation and timer restart.

**Why is `selectedDate` separate from the other `filters`?**
They do different jobs. The date filter changes the whole page (dashboard,
charts, list), while search, type and category only change the list. Keeping
them apart makes the two-step filtering clear in `App.jsx`.

**Why is `selectedDate` in App and not inside `DateFilter`?**
Three things need it (Dashboard, Analytics, List) and two things can change it
(DateFilter and the list's date headings). Shared state lives in the closest
common parent, which is App.

**Why does `Analytics` have its own state instead of App?**
No other component needs to know which chart is selected. State should live
as close as possible to where it's used.

**What happens if two transactions are added in the same millisecond?**
`Date.now()` could repeat. In production I'd use `crypto.randomUUID()` or IDs
from a database.

**How would you add a backend?**
Replace `storage.js` with API calls (`fetch`) to a Node/Express + MongoDB
server. Components wouldn't change, because they only talk to App.

## 10. Possible improvements

- Monthly trend chart (credit vs debit per month)
- Date range filter (from–to, this week, this month)
- Export to CSV
- Backend + login
- `useReducer` or Context API as state grows
- Unit tests for `calculations.js` with Vitest
